<template>
  <div>
    <div class="alert alert-success" style="font-size:20px;" role="alert">{{ message }}</div>
    <br/>
  </div>
</template>

<script>
export default {
  props: ['message'],
};
</script>