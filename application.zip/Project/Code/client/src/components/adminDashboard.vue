<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2&nbsp;-&nbsp;Administrator Dashboard</h2>
          <p align="right">
        &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
        </p>
        </div>
      
      </nav>
      <BR/><BR/>
      
      <div class="card-body" align="center">
     
        <div class="card-body" align="center">
          <router-link to="/adminSections"><button class="btn btn-default active" >1. SECTION MANAGEMENT</button><br><br></router-link>
          <router-link to="/showChangeRequests"><button class="btn btn-default active" >2. REVIEW SECTION CHANGES</button><br><br></router-link>
          <router-link to="/showStoreManagerRegistrations"><button class="btn btn-default active" >3. REVIEW STORE MANAGER REGISTRATIONS</button><br><br><br></router-link>
      </div>
      </div>
    </div>
  </div>
</template>

<script>
 export default {
  data() {
    return {  
    
    };
  },
    components: {
  
  },

  computed: { 
    message() {
      return this.$store.state.message;
    },
  },

  methods: {
    
    
    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoAdminLogin');
    },
  
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  
  
  },
  created() {
  
  },
};
</script>