<template>
  <div class="container-lg px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Product Management</h2><BR></BR>
          <label for="globalsectionid" class="form-label">Filter by Category:</label>
          <select id="globalsectionid" v-model="globalsection_id">
                  <option value="" key="">All</option>  
                  <option v-for="section in availableAdminSections"  v-bind:key="section.section_id" v-bind:value="section.section_id">                    
                    {{ section.section_name }}
                  </option> 
          </select> 
          <p align="right">
            &NonBreakingSpace;&nbsp;&nbsp; <router-link to="/storeManagerDashboard">Home</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<a class="action" href="#" style="color: #478fcc;" @click="toggleAddProductModal">Create Product</a>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          </p>
        </div>
      </nav>
      <div class="card-body">
        <div class="table-responsive">
          <form>
          <table class="table table-bordered m-0">
          <thead>
            <tr>
            <!-- Set columns width -->
            <th class="text-center py-3 px-4">Product Image</th>
            <th class="text-center py-3 px-4">Product Name</th>
            <th class="text-center py-3 px-4">Section Name</th>
            <th class="text-center py-3 px-4">Maximum Price</th>
            <th class="text-center py-3 px-4">Avaiable Quantity</th>
            <th class="text-center py-3 px-4">Units Sold</th>
            <th class="text-center py-3 px-4">Unit of Measure</th>
            <th class="text-center py-3 px-4">Mfg/Expiry Date:</th>            
            <th class="text-center py-3 px-4">Edit</th>
            <th class="text-center py-3 px-4">Delete</th>
            </tr>
          </thead>
          <tbody>

            <tr v-for="(product, index) in availableAdminProducts" :key="index">
              <td class="p-4">               
                  <Img class="img-thumbnail" style="width: 175px; height: 100px;" :src=getImageUrl(product.image_name) alt="productImg" />
              </td>
              <td>
                <a href="#" class="d-block text-dark">{{ product.product_name }}</a>
              </td>  
              <td>
                  <span class="text-muted"> {{ product.section_name }}</span>                  
              </td>
              <td> 
                 <span class="text-muted"></span>{{ product.price }}&nbsp;
              </td>
              <td> 
                 <span class="text-muted"></span>{{ product.available_qty }}&nbsp;
              </td>
              <td> 
                 <span class="text-muted"></span>{{ product.units_sold }}&nbsp;
              </td>
              <td> 
                 <span class="text-muted"></span>{{ product.measure_of_units }}&nbsp;
              </td>
              <td> 
                 <span class="text-muted"></span>{{ product.Manufacture_or_Expiry_Date }}&nbsp;
              </td>             
              <td class="text-center align-middle px-0"><a href="#"  @click="toggleEditProductModal(product)" class="shop-tooltip close float-none text-danger" productname="" data-original-productname="Save">
                <img src="../../public/edit4.png" alt=""></a>
              </td>
              <td class="text-center align-middle px-0"><a href="#" @click="handleDeleteProduct(product)" class="shop-tooltip close float-none text-danger" productname="" data-original-productname="Remove">
                <img src="../../public/delete4.png" alt=""></a>
              </td>
            </tr>
          
          </tbody>
          </table>
        </form>
      </div>
    </div>
  </div>

  <!-- add new product modal -->
  <div ref="addProductModal" class="modal fade" :class="{ show: activeAddProductModal, 'd-block': activeAddProductModal }"
    tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-productname">Add a new product</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="toggleAddProductModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="mb-3">
              <label for="addproductname" class="form-label">Product Name</label>
              <input type="text" class="form-control" id="addproductname" v-model="addProductForm.product_name"
                placeholder="Enter productname">
            </div>
            <div class="mb-3">
              <label for="sectionid" class="form-label">Section Name</label>
              <select id="sectionid" v-model="addProductForm.section_id">
                    <option v-for="section in availableAdminSections"  v-bind:key="section.section_id" v-bind:value="section.section_id">                    
                    {{ section.section_name }}
                  </option> 
              </select> 
            </div>
            <div class="mb-3">
              <label for="addprice" class="form-label">Maximum Price</label>
              <input type="text" class="form-control" id="addprice" v-model="addProductForm.price"
                placeholder="Enter Maximum Price">
            </div>
            <div class="mb-3">
              <label for="addquantity" class="form-label">Avaiable Quantity</label>
              <input type="text" class="form-control" id="addquantity" v-model="addProductForm.available_qty"
                placeholder="Enter Avaiable Quantity">
            </div>
            <div class="mb-3">
              <label for="addquantity" class="form-label">Units Sold</label>
              <input type="text" class="form-control" id="addquantity" v-model="addProductForm.units_sold"
                placeholder="Enter Units Sold">
            </div>
            <div class="mb-3">
              <label for="addunitofmeasure" class="form-label">Unit of Measure</label>
              <input type="text" class="form-control" id="addunitofmeasure" v-model="addProductForm.measure_of_units"
                placeholder="Enter Unit of Measure">
            </div>
            <div class="mb-3">
              <label for="addmfgdate" class="form-label">Manufacture/Expiry Date</label>
              <input type="date" class="form-control" id="addmfgdate" v-model="addProductForm.Manufacture_or_Expiry_Date"
                placeholder="Enter Manufacture/Expiry Date">
            </div>           
            
            <div class="mb-3">    
              <label class="form-label" for="file-input">Product Image:</label>    
              <input
                id="file-input"
                class="form-control"
                type="file"
                accept="image/*"
                @change="handleFileChange"
                required
              />
            </div>

            <div class="btn-group" role="group">
              <button type="button" class="btn btn-primary btn-sm" @click="handleAddSubmit">
                Submit
              </button>
              <button type="button" class="btn btn-danger btn-sm" @click="handleAddReset">
                Reset
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div v-if="activeAddProductModal" class="modal-backdrop fade show"></div>

  <!-- edit product modal -->
  <div ref="editProductModal" class="modal fade" :class="{ show: activeEditProductModal, 'd-block': activeEditProductModal }"
    tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-productname">Update</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="toggleEditProductModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="mb-3">
              <label for="addproductname" class="form-label">Product Name</label>
              <input type="text" class="form-control" id="addproductname" v-model="editProductForm.product_name"
                placeholder="Enter productname">
            </div>
            <div class="mb-3">
              <label for="sectionid" class="form-label">Section Name</label>
              <select id="sectionid" v-model="editProductForm.section_id">
                    <option v-for="section in availableAdminSections"  v-bind:key="section.section_id" v-bind:value="section.section_id">                    
                    {{ section.section_name }}
                  </option> 
              </select> 
            </div>
            <div class="mb-3">
              <label for="addprice" class="form-label">Maximum Price</label>
              <input type="text" class="form-control" id="addprice" v-model="editProductForm.price"
                placeholder="Enter Maximum Price">
            </div>
            <div class="mb-3">
              <label for="addquantity" class="form-label">Avaiable Quantity</label>
              <input type="text" class="form-control" id="addquantity" v-model="editProductForm.available_qty"
                placeholder="Enter Avaiable Quantity">
            </div>
            <div class="mb-3">
              <label for="addquantity" class="form-label">Units Sold</label>
              <input type="text" class="form-control" id="addquantity" v-model="editProductForm.units_sold"
                placeholder="Enter Units Sold">
            </div>
            <div class="mb-3">
              <label for="addunitofmeasure" class="form-label">Unit of Measure</label>
              <input type="text" class="form-control" id="addunitofmeasure" v-model="editProductForm.measure_of_units"
                placeholder="Enter Unit of Measure">
            </div>
            <div class="mb-3">
              <label for="editmfgdate" class="form-label">Manufacture/Expiry Date</label>
              <input type="date" class="form-control" id="editmfgdate" v-model="editProductForm.Manufacture_or_Expiry_Date"
                placeholder="Enter Manufacture/Expiry Date">
            </div>  
            
            <div class="mb-3">    
              <label class="form-label" for="file-input">Product Image:</label>    
              <input
                id="file-input"
                class="form-control"
                type="file"
                accept="image/*"
                @change="handleFileChange"
                required
              />
            </div>

            <div class="btn-group" role="group">
              <button type="button" class="btn btn-primary btn-sm" @click="handleEditSubmit">
                Submit
              </button>
              <button type="button" class="btn btn-danger btn-sm" @click="handleEditCancel">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div v-if="activeEditProductModal" class="modal-backdrop fade show"></div>
  </div>
</template>

<script>
import axios from 'axios';
import Alert from './Alert.vue';

export default {
  data() {
    return {
      filename: '',
      globalsection_id: '',
      activeAddProductModal: false,
      addProductForm: {
        product_name:'',
        price: '',
        image_name: '',
        available_qty: '',
        units_sold: '',
        measure_of_units: '',
        section_id: '',
        Manufacture_or_Expiry_Date: '',
        section_name: '',        
      },
      activeEditProductModal: false,
      editProductForm: {
        id: '',
        product_name:'',
        price: '',
        image_name: '',
        available_qty: '',
        units_sold: '',
        measure_of_units: '',
        section_id: '',
        Manufacture_or_Expiry_Date: '', 
        section_name: '',
      },
      adminproducts: [],
      message: '',
      fd: '',
    };
  },
  components: {
    alert: Alert,
  },

  watch: {
    globalsection_id: function (newVal, oldVal) {    
      this.$store.dispatch('setGlobalSectionId', newVal);      
    },
  },

  computed: {   
    availableAdminProducts() {
      console.log('admin products from store', this.$store.state.adminproducts);
      //return this.$store.state.adminproducts;
      return this.$store.getters.filterAdminProducts;
    },


    availableAdminSections() {
      console.log('admin sections from store', this.$store.state.adminsections);
      return this.$store.state.adminsections;
    },
  },
  methods: {

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoStoreManagerLogin');
    },

    handleFileChange: function (event) {
      let img = event.target.files[0];
      console.log('i am here..');   
      this.fd = new FormData();
      this.fd.append('image', img);
      this.filename = img.name;
      console.log('file attached here', img.name);
    },

    getImageUrl(img) {
      console.log('image name is', new URL(`../assets/${img}`, import.meta.url).href);
      return new URL(`../assets/${img}`, import.meta.url).href;
    },

  
    handleAddReset() {
      this.initForm();
    },
    handleAddSubmit() {
      this.toggleAddProductModal();      
      console.log('selected section id is', this.addProductForm.section_id);
      const payload = {
        productname:this.addProductForm.product_name,
        price: this.addProductForm.price,  
        filename: this.filename,
        availableqty: this.addProductForm.available_qty,
        unitssold: this.addProductForm.units_sold,
        unitofmeasure: this.addProductForm.measure_of_units,
        sectionid: this.addProductForm.section_id,
        mfgDate: this.addProductForm.Manufacture_or_Expiry_Date,

      };   
      this.fd.append('data', JSON.stringify(payload))
      this.$store.dispatch('addAdminProductToStore', this.fd);

      this.initForm();
      window.scrollTo(0, document.body.scrollHeight);

      this.$store.dispatch('getAdminSections');
      this.$store.dispatch('getAdminProducts');

    },

    handleEditCancel() {
      this.toggleEditProductModal(null);
      this.initForm();
      this.$store.dispatch('getAdminProducts');
    },

    handleDeleteProduct(product) {
      //this.removeProduct(product.product_id);
      if (confirm ('Are you sure you want to delete the selected Product?'))
        this.$store.dispatch('deleteProductToStore', product.product_id);
    },

    initForm() {
      this.addProductForm.product_name = '';
      this.addProductForm.price = '';
      this.addProductForm.measure_of_units = '';
      this.addProductForm.available_qty = '';
      this.addProductForm.units_sold = '';
      this.addProductForm.Manufacture_or_Expiry_Date = '';
      this.addProductForm.section_id = '';
      this.addProductForm.section_name = '';
      
      this.editProductForm.id = '';      
      this.editProductForm.product_name = '';
      this.editProductForm.price = '';
      this.editProductForm.measure_of_units = '';
      this.editProductForm.available_qty = '';
      this.editProductForm.units_sold = '';
      this.editProductForm.Manufacture_or_Expiry_Date = '';
      this.editProductForm.section_id = '';
      this.addProductForm.section_name = '';

      this.fd = new FormData();
      this.filename = '';
      this.message = '';

    },
    toggleAddProductModal() {
      const body = document.querySelector('body');
      this.activeAddProductModal = !this.activeAddProductModal;
      if (this.activeAddProductModal) {
        body.classList.add('modal-open');
      } else {
        body.classList.remove('modal-open');
      }
    },

    toggleEditProductModal(product) {
      if (product) {
        this.editProductForm = product;
        this.editProductForm.id = product.product_id;
        console.log('product id is ...', this.editProductForm.id );
      }
      const body = document.querySelector('body');
      this.activeEditProductModal = !this.activeEditProductModal;
      if (this.activeEditProductModal) {
        body.classList.add('modal-open');
      } else {
        body.classList.remove('modal-open');
      }
    },

    handleEditSubmit() {     
      console.log('I am here..')
      this.toggleEditProductModal(null);      
      const payload = {
        productname:this.editProductForm.product_name,
        price: this.editProductForm.price,  
        filename: this.filename,
        availableqty: this.editProductForm.available_qty,
        unitssold: this.editProductForm.units_sold,
        unitofmeasure: this.editProductForm.measure_of_units,
        sectionid: this.editProductForm.section_id,
        mfgDate: this.editProductForm.Manufacture_or_Expiry_Date,
      };   
      this.fd.append('data', JSON.stringify(payload))
      console.log('product id being passed is ...', this.editProductForm.id );

      const payload2 = {
        fd: this.fd,
        productid: this.editProductForm.id,    
      };
      this.$store.dispatch('editAdminProductToStore', payload2);
      this.initForm();

    },  
  },
  created() {
    this.$store.dispatch('getAdminSections');
    this.$store.dispatch('getAdminProducts');
    this.initForm();
  },
};
</script>