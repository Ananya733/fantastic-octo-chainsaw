<template>
  <div class="container px-3 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header" style="float:right;" v-if="cart">
          <h2>KA Mart V2 <i>powered by Vue JS 3</i></h2>
          <p>
            Hello,&nbsp;{{ userDetails.greetingName }}
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          <div align=right>
            <router-link to="/showOrders">My Orders</router-link> |
            &NonBreakingSpace;&nbsp;&nbsp;<router-link to="/showCart">Show Cart</router-link>
            <div class="cart-items">
              {{ cart.length }}
            </div>
            
          </div>
          </p>
        </div>
      </nav>
      <div class="card-body">
        <div class="page-content container">
          <div class="page-header text-blue-d2">
            <h1 class="page-title text-secondary-d1">
              ORDER SUMMARY
              <hr>
            </h1>
          </div>
          <div class="container px-0">
            <div class="row">
              <div class="col-12 col-lg-12">
                <div class="row">
                  <div class="col-sm-6">
                    <div>
                      <br>
                      <span class="text-uppercase h4 text-font">Delivery Address<p></p></span>
                      <span class="text-600 text-110 text-blue align-middle">{{ userDetails.firstname }}&nbsp;{{
                        userDetails.lastname }}</span>
                    </div>
                    <div class="text-grey-m2">
                      <div class="my-1">
                        {{ userDetails.shipping_addr }}<BR></BR>{{ userDetails.city }}
                      </div>
                      <div class="my-1">
                        {{ userDetails.state }}<BR></BR>{{ userDetails.country }}<BR></BR>{{ userDetails.pin }}
                      </div>
                      <div class="my-1"><i class="fa fa-phone fa-flip-horizontal text-secondary"></i> {{ userDetails.phone
                      }}</div>
                    </div>
                    <BR></BR>
                  </div>
                  <!-- /.col -->

                  <div class="text-95 col-sm-6 align-self-start d-sm-flex justify-content-end">
                    <hr class="d-sm-none" />
                    <div class="text-grey-m2">

                      <BR></BR><BR></BR><BR></BR>

                      <div class="my-2"><i class="fa fa-circle text-blue-m2 text-xs mr-1"></i> <span
                          class="text-600 text-90">Cart ID:</span> # {{ cart_id }}</div>

                      <div class="my-2"><i class="fa fa-circle text-blue-m2 text-xs mr-1"></i> <span
                          class="text-600 text-90">Issue Date:</span> {{ currentDate() }} </div>

                      <div class="my-2"><i class="fa fa-circle text-blue-m2 text-xs mr-1"></i> <span
                          class="text-600 text-90">Status:</span> Unpaid</div>
                    </div>
                  </div>
                  <!-- /.col -->
                </div>

                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Description</th>
                      <th scope="col">Price</th>
                      <th scope="col">Quantity</th>                    
                      <th scope="col">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(product, index) in cart" :key="index">
                      <th scope="row">{{ index+1 }}</th>
                      <td>{{ product.product_name }}</td>
                      <td>₹{{ product.price }}/{{ product.measureofunit }}</td>
                      <td>{{ product.quantity }}</td>
                      <td>₹{{ product.total }}</td>
                    </tr>
                    <tr>
                      <td style="border:none" colspan="5">&nbsp;</td>
                    </tr>
                    <tr>
                      <td style="border:none" colspan="5">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" style="border:none">&nbsp;</td>
                      <td colspan="1" style="text-align:right; border:none">Sub Total</td>
                      <td style="border:none">₹{{ totalPrice }}</td>
                    </tr>
                    <tr>
                      <td colspan="3" style="border:none">&nbsp;</td>
                      <td colspan="1" style="text-align:right; border:none">Tax (10%)</td>
                      <td style="border:none">₹{{ tax }}</td>
                    </tr>
                    <tr>
                      <td colspan="3" style="border:none">&nbsp;</td>
                      <td colspan="1" style="text-align:right; border:none"><strong>Total Amount</strong></td>
                      <td style="border:none">₹{{ totalWithTax }}</td>
                    </tr>
                  </tbody>
                </table>

                <div class="mt-4 float-right" style="align:right">


                  <div class="row border-b-2 brc-default-l2"></div>


                  <hr />
                  <div>
                    <div class="mt-4">
                      <label class="text-muted font-weight-normal">Payment Method</label>
                      <select name="paymentmethod" id="paymentmethod">
                        <option value="COD">Cash On Delivery</option>
                        <option value="CardOD">Card On Delivery</option>
                      </select>
                    </div>
                    <button type="button" @click="placeOrder" class="btn btn-primary  md-btn-flat mt-2 mr-3"
                      style="float:right; font-size: large; background-color: #478fcc; border-color: #478fcc;">Place
                      Order</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
    }
  },
  computed: {
    cart() {
      console.log('console cart is:', this.$store.getters.cart);
      return this.$store.getters.cart;
    },
    cart_id() {
      console.log('console cart is:', this.$store.getters.cart_id);
      return this.$store.getters.cart_id;      
    },
    totalQuantity() {
      return this.$store.getters.totalQuantity;
    },
    totalPrice() {
      return (this.$store.getters.totalPrice).toFixed(2);
    },
    userDetails() {
      return this.$store.getters.userDetails;
    },
    tax() {
      return (this.$store.getters.totalPrice * 0.1).toFixed(2);;
    },
    totalWithTax() {
      return (this.$store.getters.totalPrice * 1.1).toFixed(2);
    },

  },

  created() {
    this.$store.dispatch('getCart');    
  },

  methods: {

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoLogin');
    },
    
    placeOrder() {     
      this.$store.dispatch('placeOrder');    
    },

    currentDate() {
      const current = new Date();
      const date = `${current.getDate()}/${current.getMonth() + 1}/${current.getFullYear()}`;
      return date;
    }
  }
}

</script>
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {

  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
