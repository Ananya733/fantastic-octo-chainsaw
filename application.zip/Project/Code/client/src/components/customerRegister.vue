<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2&nbsp;-&nbsp;Customer Registration</h2>
          <p align="right">
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="mainmenu">Main Menu</a><BR></BR>
          </p>
        </div>
      </nav>
      <BR/><BR/>
      <alert :message="message" v-if="message != ''"></alert>

      <div class="card-body"  align="center">  
        <form method="post">
          <table class="table table-unbordered m-0">
            <tr>              
              <td align="right">
                 <label for="username">Username</label>
             </td>             
              <td>
                <input type="text" id="username" required v-model="loginForm.username" placeholder="Enter Username"/>
                <BR/><BR/>
              </td>
            </tr>
            <tr>
              <td align="right">
                <label for="password">Password</label>
              </td>
              <td>
                <input type="text" id="password" required v-model="loginForm.password" placeholder="Enter Password"/>
                <BR/><BR/>
              </td>
            </tr>
            <tr>
              <td align="right">
                <label for="firstname">First Name</label>
              </td>
              <td>
                <input type="text" id="firstname" required v-model="loginForm.firstname" placeholder="Enter First Name"/>
                <BR/><BR/>
              </td>
            </tr>
            <tr>
              <td align="right">
                <label for="lastname">Last Name</label>
              </td>
              <td>
                <input type="text" id="lastname" required v-model="loginForm.lastname" placeholder="Enter Last Name"/>
                <BR/><BR/>
              </td>
            </tr>  
            <tr>
              <td align="right">
                <label for="email">Email</label>
              </td>
              <td>
                <input type="text" id="email" required v-model="loginForm.email" placeholder="Enter Email"/>
                <BR/><BR/>
              </td>
            </tr>   
            <tr>
              <td align="right">
                <label for="phone">Phone</label>
              </td>
              <td>
                <input type="text" id="phone" required v-model="loginForm.phone" placeholder="Enter Phone"/>
                <BR/><BR/>
              </td>
            </tr>   
            <tr>
              <td align="right">
                <label for="shippingaddress">Shipping Address</label>
              </td>
              <td>
                <input type="text" id="shippingaddress" required v-model="loginForm.shippingaddress" placeholder="Enter Shipping Address"/>
                <BR/><BR/>
              </td>
            </tr>    
            <tr>
              <td align="right">
                <label for="city">City</label>
              </td>
              <td>
                <input type="text" id="city" required v-model="loginForm.city" placeholder="Enter City"/>
                <BR/><BR/>
              </td>
            </tr>    
            <tr>
              <td align="right">
                <label for="state">State</label>
              </td>
              <td>
                <input type="text" id="state" required v-model="loginForm.state" placeholder="Enter State"/>
                <BR/><BR/>
              </td>
            </tr>    
            <tr>
              <td align="right">
                <label for="country">Country</label>
              </td>
              <td>
                <input type="text" id="country" required v-model="loginForm.country" placeholder="Enter Country"/>
                <BR/><BR/>
              </td>
            </tr>  
            <tr>
              <td align="right">
                <label for="country">PIN</label>
              </td>
              <td>
                <input type="text" id="pin" required v-model="loginForm.pin" placeholder="Enter PIN"/>
                <BR/><BR/>
              </td>
            </tr> 
            <tr>              
              <td colspan="2" align="center">              
                <input type="button" class="btn btn-primary" @click="doRegister" value="Register"/>
              </td>
            </tr> 
          </table>
        </form>
      </div>
    </div>
  </div>
</template>

<script>

import Alert from './Alert.vue';

export default {
  data() {
    return {  
      loginForm: {
        username: '',
        password: '',
        firstname: '',
        lastname: '',
        email: '',
        phone: '',  
        shippingaddress: '',
        city: '',
        state: '',
        country: '',  
        pin: '',
      },     
      message: '',
    };
  },
    components: {
    alert: Alert,
  },

  computed: {   
      message() {
      return this.$store.state.message;
    },
  },

  methods: {      
    doRegister() {
        if (this.loginForm.username == '' || this.loginForm.password == '') {
          this.$store.dispatch('setMessage','Pleas enter Username and Password to Register');
          return false;
        }      
        console.log('I am here with payload');
        const payload = {
            username: this.loginForm.username,
            password: this.loginForm.password,  
            firstname: this.loginForm.firstname,
            lastname: this.loginForm.lastname,
            email: this.loginForm.email,
            phone: this.loginForm.phone,  
            shippingaddress: this.loginForm.shippingaddress,
            city: this.loginForm.city,
            state: this.loginForm.state,
            country: this.loginForm.country,  
            pin: this.loginForm.pin,    
          };
        this.$store.dispatch('customerRegister', payload);       
    },

    mainmenu() {
      console.log('hey I am here');
      this.$store.dispatch('gotoMainMenu');
    },
   
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  

  },
  created() {
   
  },
};
</script>