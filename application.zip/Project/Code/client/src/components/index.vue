<template>
 <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2</h2>
        </div>
      </nav>
      <div class="card-body" align="center">
          <br><br>
          <router-link to="/adminLogin"><button class="btn btn-default active" >ADMIN LOGIN</button><br><br></router-link>    
          <router-link to="/customerLogin"><button class="btn btn-default active" >CUSTOMER LOGIN</button><br><br></router-link>
          <router-link to="/storeManagerLogin"><button class="btn btn-default active" >STORE MANAGER LOGIN</button><br><br></router-link>   
          <router-link to="/customerRegister"><button class="btn btn-default active" >REGISTER AS CUSTOMER</button><br><br></router-link>
          <router-link to="/storeManagerRegister"><button class="btn btn-default active" >REGISTER AS STORE MANAGER</button><br><br><br></router-link>
      </div>
    </div>

  </div>

</template>

<script>

import Alert from './Alert.vue';

export default {
  data() {
    return {  
      loginForm: {
        username: '',
        password: '',    
      },     
      message: '',
    };
  },
    components: {
    alert: Alert,
  },

  computed: {   
  },

  methods: {      
    doLogin() {
        if (this.loginForm.username == '' || this.loginForm.password == '') {
          this.message = 'Pleas enter Username and Password to Login';
          return false;
        }
      
        console.log('I am here with payload');
        const payload = {
            username: this.loginForm.username,
            password: this.loginForm.password,      
        };

        this.$store.dispatch('adminLogin', payload);       
      },

   
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  
  
  },
  created() {
    
  },
};
</script>