<template>
  <div class="container-lg px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Section Change Requests</h2>
          <p align="right">
            &NonBreakingSpace;&nbsp;&nbsp; <router-link to="/storeManagerDashboard">Home</router-link>            
            &NonBreakingSpace;&nbsp;&nbsp;<a class="action" href="#" style="color: #478fcc;" @click="toggleAddSectionModal">Create Section</a>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          </p>
        </div>
      </nav>
      <div class="card-body">
        <div class="table-responsive">
          <form>
          <table class="table table-bordered m-0">
          <thead>
            <tr>
            <!-- Set columns width -->
            <th class="text-center py-3 px-4">Section Id</th>
            <th class="text-center py-3 px-4">Section Name</th>
            <th class="text-center py-3 px-4">Section Description</th>
            <th class="text-center py-3 px-4">Delete</th>
            <th class="text-center py-3 px-4">Edit</th>
            </tr>
          </thead>
          <tbody>

            <tr v-for="(section, index) in availableSections" :key="index">
              <td>
                <a href="#" class="d-block text-dark text-center">{{ section.section_id }}</a>
              </td> 
              <td>
                <a href="#" class="d-block text-dark text-center">{{ section.section_name }}</a>
              </td>   
              <td> 
                <small>
                <span class="text-muted text-center"></span>{{ section.section_description }}&nbsp;
                </small>
              </td>
              <td class="text-center align-middle px-0"><a href="#" @click="handleDeleteSection(section)" class="shop-tooltip close float-none text-danger" section_name="" data-original-section_name="Remove">
                <img src="../../public/delete4.png" alt=""></a>
              </td>
              <td class="text-center align-middle px-0"><a href="#"  @click="toggleEditSectionModal(section)" class="shop-tooltip close float-none text-danger" section_name="" data-original-section_name="Save">
                <img src="../../public/edit4.png" alt=""></a>
              </td>
            </tr>
          
          </tbody>
          </table>
        </form>
      </div>
    </div>
  </div>

  <!-- add new section modal -->
  <div ref="addSectionModal" class="modal fade" :class="{ show: activeAddSectionModal, 'd-block': activeAddSectionModal }"
    tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-section_name">Add a new section</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="toggleAddSectionModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="mb-3">
              <label for="addsection_name" class="form-label">section Name</label>
              <input type="text" class="form-control" id="addsection_name" v-model="addSectionForm.section_name"
                placeholder="Enter section_name">
            </div>
            <div class="mb-3">
              <label for="addsection_description" class="form-label">Section Desciption:</label>
              <input type="text" class="form-control" id="addsection_description" v-model="addSectionForm.section_description"
                placeholder="Enter Description">
            </div>      
            <div class="btn-group" role="group">
              <button type="button" class="btn btn-primary btn-sm" @click="handleAddSubmit">
                Submit
              </button>
              <button type="button" class="btn btn-danger btn-sm" @click="handleAddReset">
                Reset
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div v-if="activeAddSectionModal" class="modal-backdrop fade show"></div>

  <!-- edit section modal -->
  <div ref="editSectionModal" class="modal fade" :class="{ show: activeEditSectionModal, 'd-block': activeEditSectionModal }"
    tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-section_name">Update</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="toggleEditSectionModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="mb-3">
              <label for="editsection_name" class="form-label">Section Name:</label>
              <input type="text" class="form-control" id="editsection_name" v-model="editSectionForm.section_name"
                placeholder="Enter section_name">
            </div>
            <div class="mb-3">
              <label for="editsection_description" class="form-label">Section Desciption:</label>
              <input type="text" class="form-control" id="editsection_description" v-model="editSectionForm.section_description"
                placeholder="Enter Description">
            </div>
               
            <div class="btn-group" role="group">
              <button type="button" class="btn btn-primary btn-sm" @click="handleEditSubmit">
                Submit
              </button>
              <button type="button" class="btn btn-danger btn-sm" @click="handleEditCancel">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div v-if="activeEditSectionModal" class="modal-backdrop fade show"></div>
  </div>
</template>

<script>
import axios from 'axios';
import Alert from './Alert.vue';

export default {
  data() {
    return {
      filename: '',
      activeAddSectionModal: false,
      addSectionForm: {
        section_name:'',
        section_description: '',
     },
      activeEditSectionModal: false,
      editSectionForm: {
        id: '',
        section_name:'',
        section_description: '',
       },
      adminsections: [],
      message: '',
      fd: new FormData(),
    };
  },
  components: {
    alert: Alert,
  },

  computed: {   
    availableSections() {
      console.log('sections from store', this.$store.state.adminsections);
      return this.$store.state.adminsections;
    },

    userDetails() {
      console.log('role ==', this.$store.getters.userDetails.role);
      return this.$store.getters.userDetails;
    },

  },
  methods: {

    logout() {
      if (this.userDetails.role == 'admin')       
      this.$store.dispatch('gotoAdminLogin');
      else if (this.userDetails.role=='storemanager')
      this.$store.dispatch('gotoStoreManagerLogin');
    },
  
    handleAddReset() {
      this.initForm();
    },
    handleAddSubmit() {
      this.toggleAddSectionModal();      
      const payload = {
        title:this.addSectionForm.section_name,
        body: this.addSectionForm.section_description,  
     };   
      this.fd.append('data', JSON.stringify(payload))
      this.$store.dispatch('addSectionCRToStore', this.fd);

      this.initForm();
      window.scrollTo(0, document.body.scrollHeight);

    },

    handleEditCancel() {
      this.toggleEditSectionModal(null);
      this.initForm();
      this.$store.dispatch('getAdminSections');
    },

    handleDeleteSection(section) {
      //this.removeSection(section.section_id);
      if (confirm ('Are you sure you want to request deletion of the selected Section?'))
        this.$store.dispatch('deleteSectionCRToStore', section.section_id);
    },

    initForm() {
      this.addSectionForm.section_name = '';
      this.addSectionForm.section_description = '';
      this.editSectionForm.id = '';
      this.editSectionForm.section_name = '';
      this.editSectionForm.section_description = '';
     this.message = '';
    },
    toggleAddSectionModal() {
      const body = document.querySelector('body');
      this.activeAddSectionModal = !this.activeAddSectionModal;
      if (this.activeAddSectionModal) {
        body.classList.add('modal-open');
      } else {
        body.classList.remove('modal-open');
      }
    },

    toggleEditSectionModal(section) {
      if (section) {
        this.editSectionForm = section;
        this.editSectionForm.id = section.section_id;
        console.log('section id is ...', this.editSectionForm.id );
      }
      const body = document.querySelector('body');
      this.activeEditSectionModal = !this.activeEditSectionModal;
      if (this.activeEditSectionModal) {
        body.classList.add('modal-open');
      } else {
        body.classList.remove('modal-open');
      }
    },

    handleEditSubmit() {     
      console.log('I am here..')
      this.toggleEditSectionModal(null);      
      const payload = {
        title:this.editSectionForm.section_name,
        body: this.editSectionForm.section_description, 
        reqid: '',
        decision: '', 
        action: 'update',  
      };   
      this.fd.append('data', JSON.stringify(payload))
      console.log('section id being passed is ...', this.editSectionForm.id );

      const payload2 = {
        fd: this.fd,
        sectionid: this.editSectionForm.id,       
      };
      this.$store.dispatch('editSectionCRToStore', payload2);      
      this.$store.dispatch('getAdminSections');
      this.initForm();    

    },

  },
  created() {
    this.$store.dispatch('getAdminSections');
    this.initForm();
  },
};
</script>