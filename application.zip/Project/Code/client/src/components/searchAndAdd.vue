<template>
  <div class="container px-3 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card" v-if="availableProducts">

      <nav>
        <div class="card-header" style="float:right;" v-if="cart">
          <h2>KA Mart V2 <i>powered by Vue JS 3</i></h2>
          <p>
            Hello,&nbsp;{{ userDetails.greetingName }}            
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          <div align=right>
            <router-link to="/showOrders">My Orders</router-link> |
            &NonBreakingSpace;&nbsp;&nbsp;<router-link to="/showCart">Show Cart</router-link>
            <div class="cart-items">
              {{ cart.length }}
            </div>
            
          </div>
          </p>
        </div>
      </nav>

      <alert :message="message"  v-if="this.message != ''"></alert>
      <div class="card-body">
        <div class="row">
          <!-- BEGIN SEARCH RESULT -->
          <div class="col-md-12">
            <div class="grid search">
              <div class="grid-body">
                <div class="row">
                  <!-- BEGIN FILTERS -->
                  <div class="col-md-3">
                    <h2 class="grid-title"><i class="fa fa-filter"></i> Filters</h2>
                    <hr>
                    <form>
                      <div>
                        <!-- BEGIN FILTER BY CATEGORY -->
                        <h4>By category:</h4>
                        <div v-for="(section, index) in availableSections" :key="index">
                          <div class="checkbox">
                            <label><input type="checkbox" class="icheck" :id="section.section_name"
                                :value="section.section_id" v-model="checkedSections" />&nbsp;&nbsp;{{
                                  section.section_name }}</label>
                          </div>
                        </div>
                        <!-- END FILTER BY CATEGORY -->

                        <div class="padding"></div>

                        <!-- BEGIN FILTER BY DATE -->
                        <h4>By date:</h4>
                        From
                        <input type="date" class="form-control" name="fromDate" id="fromDate"
                          v-model="fromDate" />
                        <span class="input-group-addon bg-blue"></span>
                        To
                        <input type="date" class="form-control" name="toDate" id="toDate"
                          v-model="toDate" />
                        <span class="input-group-addon bg-blue"></span>
                        <!-- END FILTER BY DATE -->
                        <div class="padding"></div>

                        <!-- BEGIN FILTER BY PRICE -->
                        <h4>By price:</h4>
                        From
                        <input type="number" step="0.01" class="form-control" name="fromPrice" id="fromPrice"
                          v-model="fromPrice" />
                        <span class="input-group-addon bg-blue"></span>
                        To
                        <input type="number" step="0.01" class="form-control" name="toPrice" id="toPrice"
                          v-model="toPrice" />
                        <span class="input-group-addon bg-blue"></span>
                        <!-- END FILTER BY PRICE -->
                        <div class="padding"></div>
                      </div>
                    </form>
                  </div>
                  <!-- END FILTERS -->
                  <!-- BEGIN RESULT -->
                  <div class="col-md-9">
                    <h2><!--<i class="fa fa-file-o"></i>-->Products</h2>
                    <hr>
                    <!-- BEGIN SEARCH INPUT -->

                    <!-- Another variation with a button -->
                    <div class="input-group">
                      <input type="text" class="form-control" name="searchTerm" id="searchTerm"
                        v-model="searchTerm">
                      <div class="input-group-append">
                        <button @click="handleSearchProducts" class="btn btn-secondary" type="button" name="searchBtn">
                          Search
                        </button>
                      </div>
                    </div>

                    <!-- END SEARCH INPUT -->
                    <p>Showing all results matching {{ searchTerm }}</p>

                    <div class="padding"></div>

                    <div class="row">
                    </div>
                    <form>
                      <!-- BEGIN TABLE RESULT -->
                      <div class="table-responsive">
                        <table class="table table-hover">
                          <tbody>
                            <tr v-for="(product, index) in availableProducts" :key="index">

                              <td class="image">
                                <Img class="img-thumbnail" style="width: 96px; height: 96px;"
                                  :src=getImageUrl(product.image_name) alt="productImg" />
                              </td>
                              <td class="product"><strong>{{ product.product_name }}</strong><br>Category:&nbsp;{{
                                product.section_name }}<br>Mfg/Expiry Date:&nbsp;{{ product.Manufacture_or_Expiry_Date }}
                              </td>
                              <td class="rate text-right"><span>Price : ₹ {{ product.price }}/{{ product.measure_of_units
                              }}</span></td>

                              <div v-if="product.available_qty > 0">
                                <div class="quantity" style="align:center;">
                                  <button @click="decrement(product)" class="minus-btn" type="button" name="button"
                                    style="border:none">
                                    <img src="../../public/minus.png" alt="" />
                                  </button>
                                 
                                  <input type="text" name="name" v-model="num2[index]" @change="num2changed($event, product)"
                                    style="width:50px; height:38px; border:solid">
                                    <button @click="increment(product)" class="public/plus-btn" type="button" name="button"
                                    style="border:none">
                                    <img src="../../public/plus.png" alt="" />
                                  </button> 
                                </div>
                              </div>
                              <div v-else>
                                <td class="price text-right text-danger">&nbsp;&nbsp;&nbsp;&nbsp;Out of Stock</td>

                              </div>
                              <input type="hidden" v-model="searchedProducts[index]" />
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </form>
                    <!-- END TABLE RESULT -->
                  </div>
                  <!-- END RESULT -->

                </div>
              </div>
            </div>
            <!-- END SEARCH RESULT -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Alert from './Alert.vue';

export default {
  data() {
    return {
      checkedSections: [],  
      fromPrice: '',
      toPrice: '', 
      fromDate: '',
      toDate: '', 
      searchTerm: '',
   
      products: [],
      sections: [],
     
      num1: Array(100).fill(0),

      productSearchForm: {
        searchTerm: '',
        fromDate: '',
        toDate: '',
        fromPrice: '',
        toPrice: '',
        greetingName: '',

      },

      item: {
        product_id: '',
        price: '',
        quantity: '',
        total: '',
      }

    };
  },
  components: {
    alert: Alert,
  },

  watch: {
    checkedSections: function (newVal, oldVal) {
      // Do what you want with the selected objects:
      console.log('newval==', newVal);
      console.log('oldval==', oldVal);
      // dispatch with a payload
      this.$store.dispatch('updateCount');
      this.$store.dispatch('getFilteredProducts', newVal);
      this.$store.dispatch('setCheckedSections2',newVal);
    },

    fromPrice: function (newVal, oldVal) {
      console.log('new price', newVal);
      console.log('old price', oldVal);
      this.$store.dispatch('updateCount');
      this.$store.dispatch('updateFromPrice', newVal);
    },
    
    toPrice: function (newVal, oldVal) {
      console.log('new price', newVal);
      console.log('old price', oldVal);
      this.$store.dispatch('updateCount');
      this.$store.dispatch('updateToPrice', newVal);
    },

    fromDate: function (newVal, oldVal) {
      console.log('new price', newVal);
      console.log('old price', oldVal);
      this.$store.dispatch('updateCount');
      this.$store.dispatch('updateFromDate', newVal);
    },
    
    toDate: function (newVal, oldVal) {
      console.log('new price', newVal);
      console.log('old price', oldVal);
      this.$store.dispatch('updateCount');
      this.$store.dispatch('updateToDate', newVal);
    },
     
    searchTerm: function (newVal, oldVal) {
      console.log('new search term', newVal);
      console.log('old search term', oldVal);
      //this.$store.dispatch('updateCount');
      this.$store.dispatch('updateSearchTerm', newVal);
    },
  },

  computed: {

    
    availableProducts() {
      console.log('Total # products from store', this.$store.state.products.length);
      //return this.$store.state.products;
      return this.$store.getters.filterProducts;
    },

    fromPrice2() {
      return this.$store.getters.fromPrice2;
    },
    
    toPrice2() {
      return this.$store.getters.toPrice2;
    },
    
    fromDate2() {
      return this.$store.getters.fromDate2;
    },
    
    toDate2() {
      return this.$store.getters.toDate2;
    },

    searchTerm2() {
      return this.$store.getters.searchTerm2;
    },

    num2() {
      console.log('num2 from store', this.$store.getters.num2);
      //this.num1=this.$store.getters.num2;
      //return this.$store.state.products;
      return this.$store.getters.num2;
    },
    availableSections() {
      console.log('sections from store', this.$store.state.sections);
      return this.$store.state.sections;
    },
    searchedProducts() {
      return this.$store.state.products;
    },

    cart() {
      return this.$store.state.cart;
    },
    message() {
      return this.$store.state.message;
    },

    userDetails() {
      return this.$store.getters.userDetails;
    }
  },
  methods: {

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoLogin');
    },


    addProductToCart(id,rate,qty,amount,name, imgname, section, mfgorexpdate, measure) {
      const payload = {
        product_id: id,
        product_name: name,
        product_imagename: imgname,
        product_mfgorexpdate: mfgorexpdate,
        product_sectionname: section,
        price: rate,
        quantity: qty,
        total: amount,
        measureofunit: measure,
      }
      this.$store.dispatch('updateCart', payload);
    },

    handleSearchProducts() {
      const payload = {
        searchTerm: this.searchTerm,
      };
      console.log('payload is..', payload);
      this.$store.dispatch('searchProducts', payload);
    },

    addFind() {
      console.log('I am here...');
      this.checkedSections.push({ value: 1 });
      console.log('checkedSections', this.checkedSections);
    },

    incrementNum2(index) {
      this.$store.dispatch('incNum2',index);
    },

    
    changeNum2(index, newval) {
      this.$store.dispatch('chgNum2',index, newval);
    },    

    decrementNum2(index) {
      this.$store.dispatch('decNum2',index);
    },
    
    getImageUrl(img) {
      console.log('image name is', new URL(`../assets/${img}`, import.meta.url).href);
      return new URL(`../assets/${img}`, import.meta.url).href;
    },

  

    num2changed(event, product) {    
      console.log('user input change value:', parseInt(event.target.value));
      const index = this.availableProducts.findIndex(function(element) {
          return JSON.stringify(element) == JSON.stringify(product);
      });
      console.log('product index is ::: ' , index);
      this.changeNum2(index, parseInt(event.target.value));
     
      //console.log('new value', this.num1[index]);
      const id = this.availableProducts[index].product_id;
      const name = this.availableProducts[index].product_name;
      const section = this.availableProducts[index].section_name;
      const imgname = this.availableProducts[index].image_name;
      const mfgorexpdate =  this.availableProducts[index].Manufacture_or_Expiry_Date;
      const rate = this.availableProducts[index].price;
      const measure = this.availableProducts[index].measure_of_units;
      //const qty = this.num1[index];
      //const t = this.$store.getters.num2     
      //const qty = t[index];
      //let numarr = this.num2;
      //const qty = numarr[index];
      const qty = parseInt(event.target.value);
      console.log('new quantity after change is', qty);
      //const qty = this.$state.getters.num2[index];
      //let qty = this.availableProducts[index].qty;
      //qty++;
      const amount = rate * qty;
      this.addProductToCart(id,rate,qty,amount, name, imgname, section, mfgorexpdate, measure);
      //this.$store.dispatch('setNum2',this.num1);

    },


    increment(product) {

      const index = this.availableProducts.findIndex(function(element) {
          return JSON.stringify(element) == JSON.stringify(product);
      });

      this.incrementNum2(index);

      //console.log('new value', this.num1[index]);
      const id = this.availableProducts[index].product_id;
      const name = this.availableProducts[index].product_name;
      const section = this.availableProducts[index].section_name;
      const imgname = this.availableProducts[index].image_name;
      const mfgorexpdate =  this.availableProducts[index].Manufacture_or_Expiry_Date;
      const rate = this.availableProducts[index].price;
      const measure = this.availableProducts[index].measure_of_units;
      //const qty = this.num1[index];
      //const t = this.$store.getters.num2     
      //const qty = t[index];
      let numarr = this.num2;
      const qty = numarr[index];
      //const qty = this.$state.getters.num2[index];
      //let qty = this.availableProducts[index].qty;
      //qty++;
      const amount = rate * qty;
      this.addProductToCart(id,rate,qty,amount, name, imgname, section, mfgorexpdate, measure);
      //this.$store.dispatch('setNum2',this.num1);
    },

    decrement(product) {
   
      const index = this.availableProducts.findIndex(function(element) {
          return JSON.stringify(element) == JSON.stringify(product);
      });
      const t = this.$store.getters.num2;
     
      //if (this.num1[index] > 0) {
      if (t[index] > 0) {
        //this.num1[index]--;
        this.decrementNum2(index);
        //this.$store.dispatch('decNum2',index);
        const id = this.availableProducts[index].product_id;
        const name = this.availableProducts[index].product_name;
        const section = this.availableProducts[index].section_name;
        const imgname = this.availableProducts[index].image_name;
        const mfgorexpdate =  this.availableProducts[index].Manufacture_or_Expiry_Date;
        const rate = this.availableProducts[index].price;
        const measure = this.availableProducts[index].measure_of_units;
        //const qty = this.num1[index];
        let numarr = this.num2;
        const qty = numarr[index];
        const amount = rate * qty;
        this.addProductToCart(id,rate,qty,amount, name, imgname, section, mfgorexpdate,measure);
        //this.$store.dispatch('setNum2',this.num1);
      } 
      //console.log('new value', this.num1[index])
    },
   
  },
  created() {
    console.log('search term2 is::', this.$store.getters.searchTerm2);
    this.searchTerm = this.$store.getters.searchTerm2;
    if (this.searchTerm != '') this.handleSearchProducts();
    else this.$store.dispatch('getProducts');
    this.$store.dispatch('getSections');
    this.$store.dispatch('getCart');    
    console.log('checking if this fired');
    //this.$store.dispatch('setNum2',this.num1);
    //this.addFind();
    this.checkedSections = this.$store.getters.checkedSections2;
    this.fromPrice = this.$store.getters.fromPrice2;
    this.toPrice = this.$store.getters.toPrice2;
    this.fromDate = this.$store.getters.fromDate2;
    this.toDate = this.$store.getters.toDate2;
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
    
  },

};
</script>
<style>
.cart-items {
  position: absolute;
  top: 62px;
  right: 15px;
  font-size: 18px;
  width: 25px;
  text-align: center;
  display: inline-block;
  border-radius: 200px;
  background-color: mediumseagreen;
}

</style>