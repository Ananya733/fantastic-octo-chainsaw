<template>
  <div class="container px-3 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
  

      <nav>
        <div class="card-header" style="float:right;" v-if="cart">
          <h2>KA Mart V2 <i>powered by Vue JS 3</i></h2>
          <p>
            Hello,&nbsp;{{ userDetails.greetingName }}
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          <div align=right>
            <router-link to="/showOrders">My Orders</router-link> |
            &NonBreakingSpace;&nbsp;&nbsp;<router-link to="/searchAndAdd">Back To Shopping</router-link>         
            
          </div>
          </p>
        </div>
      </nav>

      <div class="page-header text-blue-d2">
        <h1 class="page-title text-secondary-d1">
          &nbsp;&nbsp;SHOPPING CART
          <hr>
        </h1>
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered m-0">
            <thead>
              <tr>
                <!-- Set columns width -->
                <th scope="col">#</th>
                <th class="text-center py-3 px-4" style="min-width: 280px;">Product Name &amp; Details</th>
                <th class="text-center py-3 px-4" style="width: 150px;">Price</th>
                <th class="text-center py-3 px-4" style="width: 120px;">Quantity</th>
                <th class="text-center py-3 px-4" style="width: 120px;">Total</th>
                <th class="text-center align-middle py-3 px-0" style="width: 75px;"><a href="#"
                    class="shop-tooltip float-none text-light" title="Remove" data-original-title="Clear cart"><i
                      class="ino ion-md-trash"></i></a></th>
              </tr>
            </thead>        
            <tbody>
            <tr v-for="(product, index) in cart" :key="index">
              <th scope="row">{{ index+1 }}</th>
              <td class="p-4">
                <div class="media align-items-center">
                  <Img class="img-thumbnail" style="width: 96px; height: 96px;"
                    :src=getImageUrl(product.product_imagename) alt="productImg" />

                  <div class="media-body">
                    <a href="#" class="d-block text-dark">{{ product.product_name }}</a>
                    <small>
                      <span class="text-muted">Category: </span>{{ product.product_sectionname }}&nbsp;
                      <span class="text-muted">Mfg/Expiry Date: </span> {{ product.product_mfgorexpdate }}
                    </small>
                  </div>
                </div>
              </td>
              <td class="text-center font-weight-semibold align-middle p-4">₹ {{ product.price }}/{{ product.measureofunit }}</td>
              <td class="text-center font-weight-semibold align-middle p-4"> {{ product.quantity }}</td>
              <td class="text-center font-weight-semibold align-middle p-4">{{ product.total }}</td>
              <td class="text-center align-middle px-20" style="cursor: pointer;"><a @click="removeFromCart(product)"
                  class="shop-tooltip close float-none text-danger" title="Remove" data-original-title="Remove">
                  <img style="width: 50px; height: 50px;" src="../../public/delete3.png" alt="" /></a></td>
            </tr>

            </tbody>
          </table>
        </div>
        <!-- / Shopping cart table -->

        <div class="d-flex flex-wrap justify-content-between align-items-center pb-4">
          <div class="mt-4">           
          </div>
          <div class="d-flex">
            <div class="text-right mt-4 mr-5">
              <label class="text-muted font-weight-normal m-0">Total Quantity</label>
              <div class="text-large"><strong>{{ totalQuantity }}</strong></div>
            </div>&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="text-right mt-4">
              <label class="text-muted font-weight-normal m-0">Total price</label>
              <div class="text-large"><strong>₹ {{ totalPrice }}</strong></div>
            </div>
          </div>
        </div>

        <div style="justify-content: flex-end; display: flex;">
          
          <button type="button" @click="clearCart" class="btn btn-secondary  mt-2 mr-3" style="float:right; font-size: large;">Clear Cart</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button type="button" @click="saveCart" class="btn btn-secondary  md-btn-flat mt-2 mr-3" style="float:right; font-size: large;">Save Cart</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button type="button" @click="checkout" class="btn btn-primary  md-btn-flat mt-2 mr-3" style="float:right; font-size: large; background-color: #478fcc; border-color: #478fcc;">Proceed to Payment</button>
     
        </div>
  

      </div>
    </div>
  </div>
</template>
<script>

import router from '../router';

export default {
  data() {
    return {
    }
  },
  computed: {
    cart() {
      console.log('console cart is:', this.$store.getters.cart );
      return this.$store.getters.cart;
    },
    totalQuantity() {
      return this.$store.getters.totalQuantity;
    },
    totalPrice() {
      return this.$store.getters.totalPrice;
    },
    userDetails() {
      return this.$store.getters.userDetails;
    }

  },

  created() {
    this.$store.dispatch('initMessage');
  },

  methods: {

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoLogin');
    },
    
    getImageUrl(img) {
      console.log('image name is', new URL(`../assets/${img}`, import.meta.url).href);
      return new URL(`../assets/${img}`, import.meta.url).href;
    },

    removeFromCart(product) {    
      this.$store.dispatch('removeFromCart',product);  
    },

    clearCart() {
      this.$store.dispatch('clearCart');
    },

    saveCart() {
      this.$store.dispatch('saveCart'); 
    },
    
    checkout() {
      this.$store.dispatch('checkout');
    },
  }
}

</script>
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {

  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
