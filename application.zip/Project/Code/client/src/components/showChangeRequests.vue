<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">

      <nav>
        <div class="card-header">
          <h2>Submitted Change Requests</h2>
          <p align="right">
            <div v-if="userDetails.role == 'admin'">
            <router-link to="/adminDashboard">Home</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
            </div>
            <div v-if="userDetails.role == 'storemanager'">
            <router-link to="/storeManagerDashboard">Home</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
            </div>              
           
          </p>
        </div>
      </nav>

      <hr>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered m-0">
            <thead>
              <tr>
                <!-- Set columns width -->
               <th class="text-center py-3 px-4" style="width: 50px;">Change Request #</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Section Id</th>
                <th class="text-center py-3 px-4" style="width: 100px;">Section Name</th>
                <th class="text-center py-3 px-4" style="width: 200px;">Section Description</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Requested Action</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Status</th>
                <th v-if="userDetails.role == 'admin'" class="text-center py-3 px-8" style="width: 50px;">Approve?</th>
             
              </tr>
            </thead>
            <tbody>
              <tr v-for="(CR, index) in adminsectionCRs" :key="index">
                <td class="text-center font-weight-semibold align-middle p-4" size="2"> {{ CR.request_id }}</td>
                <td class="text-center font-weight-semibold align-middle p-4"> {{ CR.section_id }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">{{ CR.section_name }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">{{ CR.section_description }}</td>
                <td class="text-center font-weight-semibold align-middle p-4"> {{ CR.action }}</td>
                <td v-if="userDetails.role == 'admin'" class="text-center font-weight-semibold align-middle p-4"> {{ CR.status }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">
                  <div v-if="CR.status == 'new' && userDetails.role == 'admin'">
                    <input type="radio" id="Yes" value="Yes" @change="completeCR('Approved', CR)" v-model="CR.status"/>
                    <label for="yes">Yes&nbsp;&nbsp;</label>
                    <input type="radio" id="No" value="No" @change="completeCR('Declined', CR)" v-model="CR.status"/>
                    <label for="No">No</label>
                  </div>
                  <div :class="{ Declined:CR.status == 'Declined', Approved:CR.status == 'Approved' }" v-else> {{ CR.status }} </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- / Shopping cart table -->
      </div>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
      fd: new FormData(),
    }
  },

  computed: {
    adminsectionCRs() {
      return this.$store.getters.adminsectionCRs;
    },  

    userDetails() {
      console.log('role ==', this.$store.getters.userDetails.role);
      return this.$store.getters.userDetails;
    }

  },
  
  created() {
    console.log('in show Change Requests');
    this.$store.dispatch('initMessage');
    this.$store.dispatch('getAdminSectionCRs');
  },

  methods: {

    logout() {

      if (this.userDetails.role == 'admin')       
        this.$store.dispatch('gotoAdminLogin');
      else if (this.userDetails.role=='storemanager')
        this.$store.dispatch('gotoStoreManagerLogin');
    },

    completeCR(decision, req) {      
      const payload = {
        title: req.section_name,
        body:  req.section_description,
        reqid: req.request_id,
        action: req.action,
        decision: decision,  
      }; 
      console.log('request id is', req.request_id);
      this.fd = new FormData();
      this.fd.append('data', JSON.stringify(payload));
    
      const payload2 = {
        fd: this.fd,
        sectionid: req.section_id,       
      };
      this.$store.dispatch('editSectionCRToStore', payload2);
    },
  },
}

</script>
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

.Declined { color: red;}
.Approved { color: green;}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {

  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
