<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">

      <nav>
        <div class="card-header" style="float:right;" v-if="cart">
          <h2>KA Mart V2 <i>powered by Vue JS 3</i></h2>
          <p>
            Hello,&nbsp;{{ userDetails.greetingName }}
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
          <div align=right>
            &NonBreakingSpace;&nbsp;&nbsp;<router-link to="/searchAndAdd">Back To Shopping</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<router-link to="/showCart">Show Cart</router-link>
            <div class="cart-items">
              {{ cart.length }}
            </div>

          </div>
          </p>
        </div>
      </nav>
      <div class="page-header text-blue-d2">
        <h1 class="page-title text-secondary-d1">
          &nbsp;&nbsp;ORDER HISTORY
          <hr>
        </h1>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered m-0">
            <thead>
              <tr>
                <!-- Set columns width -->
                <th class="text-center py-3 px-4" style="width: 50px;">Order #</th>
                <th class="text-center py-3 px-4" style="width: 250px;">Order Description</th>
                <th class="text-center py-3 px-4" style="width: 100px;">Order Date</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Order Total</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Order Status</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(order, index) in orders" :key="index">
                <td class="text-center font-weight-semibold align-middle p-4" size="2"> {{ order.order_id }}</td>
                <td class="text-center font-weight-semibold align-middle p-4"> {{ orderDescription(order.total_quantity)
                }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">{{ order.order_date }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">₹ {{ order.total_price }}</td>
                <td class="text-center font-weight-semibold align-middle p-4"> {{ order.order_status }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- / Shopping cart table -->
      </div>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {}
  },

  computed: {
    orders() {
      return this.$store.getters.orders;
    },
    cart() {
      console.log('console cart is:', this.$store.getters.cart);
      return this.$store.getters.cart;
    },

    userDetails() {
      return this.$store.getters.userDetails;
    }

  },
  
  created() {
    console.log('in show orders');
    this.$store.dispatch('initMessage');
    this.$store.dispatch('getOrders');
  },

  methods: {
    orderDescription(quantity) {
      return 'Grocery Order (' + String(quantity) + ') Items';
    },

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoLogin');
    },

  },
}

</script>
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {

  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
