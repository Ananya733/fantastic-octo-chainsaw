<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">

      <nav>
        <div class="card-header">
          <h2>Store Manager Registrations</h2>
          <p align="right">
            <div v-if="userDetails.role == 'admin'">
            <router-link to="/adminDashboard">Home</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
            </div>
            <div v-if="userDetails.role == 'storemanager'">
            <router-link to="/storeManagerDashboard">Home</router-link>
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
            </div> 
          </p>
        </div>
      </nav>

      <hr>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered m-0">
            <thead>
              <tr>
                <!-- Set columns width -->
                 <th class="text-center py-3 px-4" style="width: 50px;">User Id</th>
                <th class="text-center py-3 px-4" style="width: 50px;">User Name</th>
                <th class="text-center py-3 px-4" style="width: 100px;">User Role</th>
                <th class="text-center py-3 px-4" style="width: 200px;">User Status</th>
                <th class="text-center py-3 px-4" style="width: 50px;">Approve?</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(CR, index) in StoreManagerRegistrations" :key="index">
                <td class="text-center font-weight-semibold align-middle p-4" size="2"> {{ CR.user_id }}</td>
                <td class="text-center font-weight-semibold align-middle p-4"> {{ CR.username }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">{{ CR.role }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">{{ CR.status }}</td>
                <td class="text-center font-weight-semibold align-middle p-4">
                  <div v-if="CR.approvalstatus == 'new' && userDetails.role == 'admin'">
                    <input type="radio" id="Yes" value="Yes" @change="completeCR('Approved', CR)" v-model="CR.status"/>
                    <label for="yes">Yes&nbsp;&nbsp;</label>
                    <input type="radio" id="No" value="No" @change="completeCR('Declined', CR)" v-model="CR.status"/>
                    <label for="No">No</label>
                  </div>
                  <div :class="{ Declined:CR.approvalstatus == 'Declined', Approved:CR.approvalstatus == 'Approved' }" v-else> {{ CR.approvalstatus }} </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- / Shopping cart table -->
      </div>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
      fd: new FormData(),
    }
  },

  computed: {
    StoreManagerRegistrations() {
      return this.$store.getters.StoreManagerRegistrations;
    },  

    userDetails() {
      console.log('role ==', this.$store.getters.userDetails.role);
      return this.$store.getters.userDetails;
    }

  },
  
  created() {
    console.log('in show Change Requests');
    this.$store.dispatch('initMessage');
    this.$store.dispatch('getStoreManagerRegistrations');
  },

  methods: {

    logout() {

      if (this.userDetails.role == 'admin')       
        this.$store.dispatch('gotoAdminLogin');
      else if (this.userDetails.role=='storemanager')
        this.$store.dispatch('gotoStoreManagerLogin');
    },

    completeCR(decision, req) {      
      const payload = {
        user_id: req.user_id,
        decision: decision,  
      }; 
      console.log('request id is', req.request_id);
      this.fd = new FormData();
      this.fd.append('data', JSON.stringify(payload));
    
      const payload2 = {
        fd: this.fd,
        user_id: req.user_id,       
      };
      this.$store.dispatch('editStoreMgrRegistrationToStore', payload2);
    },
  },
}

</script>
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

.Declined { color: red;}
.Approved { color: green;}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {

  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
