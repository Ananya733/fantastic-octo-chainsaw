<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2&nbsp;-&nbsp;Store Manager Dashboard</h2>
          <p align="right">
        &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="logout">Logout</a><BR></BR>
        </p>
        </div>
      
      </nav>
      <BR/><BR/>
      <alert :message="message"  v-if="this.message != ''"></alert>

      <div class="card-body" align="center">
     
        <div class="card-body" align="center">
          <router-link to="/adminProducts"><button class="btn btn-default active" >1. PRODUCT MANAGEMENT</button><br><br></router-link>
          <router-link to="/managerSections"><button class="btn btn-default active" >2. REQUEST SECTION CHANGES</button><br><br></router-link>
          <router-link to="/showChangeRequests"><button class="btn btn-default active" >3. VIEW REQUESTED CHANGES</button><br><br></router-link>
          <button @click="handleExportCSV" style="color: #478fcc;"  class="btn btn-default active" >4. EXPORT PRODUCTS TO CSV</button><br><br>
      </div>
      </div>
    </div>
  </div>
</template>

<script>

import Alert from './Alert.vue';

export default {
  data() {
    return {  
    
    };
  },
  components: {
    alert: Alert,
  },

  computed: { 
    message() {
      return this.$store.state.message;
    },
  },

  methods: {
    
    handleExportCSV() {
        this.$store.dispatch('exportProductsCSV');
    },

    logout() {
      console.log('hey I am here');
      this.$store.dispatch('gotoAdminLogin');
    },
  
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  
  
  },
  created() {
    this.$store.dispatch('setMessage','');
  },
};
</script>