<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2&nbsp;-&nbsp;Store Manager Login</h2>
          <p align="right">
        &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="mainmenu">Main Menu</a><BR></BR>
        </p>
        </div>
      </nav>
      <BR/><BR/>
      <alert :message="message" v-if="this.message != ''"></alert>
      <div class="card-body" align="center">
        <BR/><BR/>
        <form method="post">
          <label for="username">Username</label>
            <input type="text" id="username" required v-model="loginForm.username" placeholder="Enter Username"/>
          <BR/><BR/>
          <label for="password">Password</label>
            <input type="password" id="password" required v-model="loginForm.password" placeholder="Enter Password"/>
          <BR/><BR/>
          <input type="button" @click="doLogin" value="Log In"/>
        </form>
      </div>
    </div>
  </div>
</template>

<script>

import Alert from './Alert.vue';

export default {
  data() {
    return {  
      loginForm: {
        username: '',
        password: '',    
      }, 
    };
  },
    components: {
    alert: Alert,
  },

  computed: { 
    message() {
      return this.$store.state.message;
    },
  },

  methods: {    
    
    mainmenu() {
      console.log('hey I am here');
      this.$store.dispatch('gotoMainMenu');
    },

    doLogin() {
        if (this.loginForm.username == '' || this.loginForm.password == '') {
           this.$store.dispatch('setMessage','Pleas enter Username and Password to Login');
          return false;
        }
      
        console.log('I am here with payload');
        const payload = {
            username: this.loginForm.username,
            password: this.loginForm.password,      
        };

        this.$store.dispatch('storeManagerLogin', payload);       
      },

   
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  
  
  },
  created() {
   
  },
};
</script>