<template>
  <div class="container px-5 my-5 clearfix">
    <!-- Shopping cart table -->
    <div class="card">
      <nav>
        <div class="card-header">
          <h2>Welcome to KA Mart V2&nbsp;-&nbsp;Store Manager Registration</h2>
          <p align="right">
            &NonBreakingSpace;&nbsp;&nbsp;<a href @click.stop.prevent="mainmenu">Main Menu</a><BR></BR>
          </p>
        </div>
      </nav>
      <BR/><BR/>
      <alert :message="message" v-if="message != ''"></alert>
      <div class="card-body" align="center">  
      
        <form method="post">
          <label for="username">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Username</label>
            <input type="text" id="username" required v-model="loginForm.username" placeholder="Enter Username"/>
          <BR/><BR/>
          <label for="password">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password</label>
            <input type="text" id="password" required v-model="loginForm.password" placeholder="Enter Password"/>
          <BR/><BR/>
          <label for="password">Email Address</label>
            <input type="text" id="email" required v-model="loginForm.email" placeholder="Enter Email Address"/>
          <BR/><BR/>
          <input type="button" @click="doRegister" value="Register"/>
        </form>
      </div>
    </div>
  </div>
</template>

<script>

import Alert from './Alert.vue';

export default {
  data() {
    return {  
      loginForm: {
        username: '',
        password: '',
        email: '',    
      },
    };
  },
    components: {
    alert: Alert,
  },

  computed: { 
    message() {
      return this.$store.state.message;
    },
  },

  methods: {      
    doRegister() {
        if (this.loginForm.username == '' || this.loginForm.password == '' || this.loginForm.email == '') {
          this.$store.dispatch('setMessage','Pleas enter Username, Password and Email to Register');
          return false;
        }
      
        console.log('I am here with payload');
        const payload = {
            username: this.loginForm.username,
            password: this.loginForm.password, 
            email: this.loginForm.email,     
        };

        this.$store.dispatch('storeManagerRegister', payload);       
      },

    mainmenu() {
      console.log('hey I am here');
      this.$store.dispatch('gotoMainMenu');
    },
   
    handleAddReset() {
      this.initForm();
    },   

    initForm() {
     
    },  
  
  },
  created() {
    
  },
};
</script>