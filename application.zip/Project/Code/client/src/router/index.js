import { createRouter, createWebHistory } from 'vue-router'
import Ping from '../components/ping.vue'
import customerLogin from '../components/customerLogin.vue'
import adminLogin from '../components/adminLogin.vue'
import adminDashboard from '../components/adminDashboard.vue'
import storeManagerDashboard from '../components/storeManagerDashboard.vue'
import storeManagerLogin from '../components/storeManagerLogin.vue'

import adminSections from '../components/adminSections.vue'
import managerSections from '../components/managerSections.vue'
import adminProducts from '../components/adminProducts.vue'
import searchAndAdd from '../components/searchAndAdd.vue'
import showCart from '../components/showCart.vue'
import checkout from '../components/checkout.vue'
import showOrders from '../components/showOrders.vue'
import showChangeRequests from '../components/showChangeRequests.vue'
import showStoreManagerRegistrations from '../components/showStoreManagerRegistrations.vue'

import index from '../components/index.vue'
import storeManagerRegister from '../components/storeManagerRegister.vue'
import customerRegister from '../components/customerRegister.vue'

import logout from '../components/logout.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [    
    {
      path: '/ping',
      name: 'ping',
      component: Ping
    },
    {
      path: '/customerLogin',
      name: 'customerLogin',
      component: customerLogin,
    },
    {
      path: '/storeManagerRegister',
      name: 'storeManagerRegister',
      component: storeManagerRegister,
    }, 
    {
      path: '/customerRegister',
      name: 'customerRegister',
      component: customerRegister,
    },    
    {
      path: '/adminLogin',
      name: 'adminLogin',
      component: adminLogin,
    },
    {
      path: '/adminDashboard',
      name: 'adminDashboard',
      component: adminDashboard,
    },
    {
      path: '/storeManagerDashboard',
      name: 'storeManagerDashboard',
      component: storeManagerDashboard,
    },
    {
      path: '/storeManagerLogin',
      name: 'storeManagerLogin',
      component: storeManagerLogin,
    },
    {
      path: '/adminSections',
      name: 'adminSections',
      component: adminSections,
    },
    {
      path: '/managerSections',
      name: 'managerSections',
      component: managerSections,
    },
    {
      path: '/adminProducts',
      name: 'adminProducts',
      component: adminProducts,
    },
    {
      path: '/searchAndAdd',
      name: 'searchAndAdd',
      component: searchAndAdd,
    },
    {
      path: '/showCart',
      name: 'showCart',
      component: showCart,
    },
    {
      path: '/checkout',
      name: 'checkout',
      component: checkout,
    },
    {
      path: '/showOrders',
      name: 'showOrders',
      component: showOrders,
    },
    {
      path: '/showChangeRequests',
      name: 'showChangeRequests',
      component: showChangeRequests,
    },
    {
      path: '/showStoreManagerRegistrations',
      name: 'showStoreManagerRegistrations',
      component: showStoreManagerRegistrations,
    },    
    {
      path: '/logout',
      name: 'logout',
      component: logout,
    },
    {
      path: '/',
      name: 'index',
      component: index,
    },
  ]
})

export default router