import { createStore } from "vuex";
import axios from 'axios';
import router from '../router';
import VuexPersistence from "vuex-persist";

const vuexLocal = new VuexPersistence({
  storage: window.localStorage,
});

export default createStore({
  state: {
    products: [],
    sections: [],
    cart: [],
    orders: [],
    sectionselections: [],
    count: 0,
    num2: Array(100).fill(0),
    checkedSections2: [],
    fromPrice2: '',
    toPrice2: '',
    fromDate2: '',
    toDate2: '',
    searchTerm2: '',
    userDetails: '',
    message: 'Welcome to KA Mart. Your trusted online grocey store.',
    cartRetrieved: 0,
    adminproducts: [],
    adminsections: [],
    adminsectionCRs: [],
    StoreManagerRegistrations: [],
    globalsectionid: '',
    totalQuantity: 0,
    totalPrice: 0,
    cart_id: '',
  },

  plugins: [vuexLocal.plugin],

  getters: {

    filterAdminProducts(state) {
        if (state.globalsectionid == '')
          return state.adminproducts;
        const array1 = state.adminproducts;
        let retval = []
        let filtered = array1.filter(el => {      
          return el.section_id == state.globalsectionid;
        });
        retval = filtered;
        return retval;
    }, 

    filterProducts(state) {
      const process = (date1, db, type) => {
        console.log('date from ui is', date1);
        if (date1 == undefined || date1 == '' || date1 == null) {
          console.log('returning 2703701800000');
          if (db == 'db') {
            if (type == 'from') return 2703701800000;
            if (type == 'to') return 0;
          }
          else return 0;
        }
        let parts = date1.split("-");
        let date2 = '';
        if (db == 'db') {
          date2 = new Date(parts[2] + "/" + parts[1] + "/" + parts[0]);
          console.log('i am here with db date', date2);
        }
        else
          date2 = new Date(parts[1] + "/" + parts[2] + "/" + parts[0]);
        if (db == 'db') console.log('date value from database is...', date2);
        else console.log('date value from filters is...', date2);
        return date2.getTime();
      };

      console.log('state.count is', state.count);
      if (state.count == 0) return state.products;
      const array1 = state.products;
      const array2 = state.sectionselections;
      const filteredProducts = (ar1, ar2) => {

        let retval = [];
        let filtered = [];
        retval = state.products;

        if (state.sectionselections.length > 0) {
          filtered = ar1.filter(el => {
            return ar2.indexOf(el.section_id) > -1;
          });
          retval = filtered;
        }

        let fromDt2 = process(state.fromDate2, '', '');
        let toDt2 = process(state.toDate2, '', '');

        const pricecheck = state.fromPrice2 > 0 && state.toPrice2 > 0 ? 'both' : (state.fromPrice2 > 0 ? 'from' : (state.toPrice2 > 0 ? 'to' : 'no'));
        const datecheck = fromDt2 > 0 && toDt2 > 0 ? 'both' : (fromDt2 > 0 ? 'from' : (toDt2 > 0 ? 'to' : 'no'));

        console.log('date check values is..', datecheck);
        console.log('pricecheck check values is..', pricecheck);
        //filter based on price values
        if (pricecheck == 'both') {
          retval = retval.filter(el => {
            return el.price >= state.fromPrice2 && el.price <= state.toPrice2;
          })

        }
        if (pricecheck == 'from') {
          retval = retval.filter(el => {
            return el.price >= state.fromPrice2;
          })

        }
        if (pricecheck == 'to') {
          retval = retval.filter(el => {
            return el.price <= state.toPrice2;
          })

        }

        //filter based on date values
        if (datecheck == 'both') {
          retval = retval.filter(el => {
            return process(el.Manufacture_or_Expiry_Date, 'db', 'from') >= fromDt2 && process(el.Manufacture_or_Expiry_Date, 'db', 'to') <= toDt2;
          })

        }
        if (datecheck == 'from') {
          retval = retval.filter(el => {
            return process(el.Manufacture_or_Expiry_Date, 'db', 'from') >= fromDt2;
          })

        }
        if (datecheck == 'to') {
          retval = retval.filter(el => {
            return process(el.Manufacture_or_Expiry_Date, 'db', 'to') <= toDt2;
          })
        }

        return retval;

      };
      let ar1 = [];
      let json1 = filteredProducts(array1, array2);
      for (let i = 0; i < json1.length; i++) {
        let obj1 = json1[i];
        console.log('obj1 isss', obj1.product_id);
        console.log('find is...', state.cart.find(item => { return item.product_id === obj1.product_id; }))
        ar1.push(state.cart.find(item => {
          return item.product_id == obj1.product_id;
        }));
      }
      state.num2 = [];
      for (let i = 0; i < ar1.length; i++) {
        if (ar1[i] === undefined)
          state.num2.push(0);
        else
          state.num2.push(ar1[i].quantity);
      }

      console.log('state.cart iss', state.cart);
      console.log('json1 iss', json1);
      console.log('ar1 isss', ar1);
      console.log('num2 isss', state.num2);
      return filteredProducts(array1, array2);
    },


    num2(state) {
      return state.num2;
    },

    message(state) {
      return state.message;
    },

    checkedSections2(state) {
      return state.checkedSections2;
    },

    adminsectionCRs(state) {
      return state.adminsectionCRs;
    },

    StoreManagerRegistrations(state) {
      return state.StoreManagerRegistrations;
    },

    fromPrice2(state) {
      return state.fromPrice2;
    },

    toPrice2(state) {
      return state.toPrice2;
    },

    fromDate2(state) {
      return state.fromDate2;
    },

    toDate2(state) {
      return state.toDate2;
    },

    searchTerm2(state) {
      return state.searchTerm2;
    },

    totalQuantity(state) {
      return state.totalQuantity;
    },

    totalPrice(state) {
      return state.totalPrice;
    },

    cart(state) {
      return state.cart;
    },
    
    cart_id(state) {
      return state.cart_id;
    },

    userDetails(state) {
      return state.userDetails;
    },

    orders(state) {
      return state.orders;
    },

  },

  mutations: {

    increment(state) {
      state.count++;
    },

    increNum2(state, index) {
      state.num2[index]++;
    },

    changeNum2(state, index, newval) {
      state.num2[index] = newval;
    },

    updateCheckedSections2(state, newval) {
      state.checkedSections2 = newval;
    },

    updFromPrice(state, newval) {
      state.fromPrice2 = newval;
    },

    updToPrice(state, newval) {
      state.toPrice2 = newval;
    },

    updFromDate(state, newval) {
      state.fromDate2 = newval;
    },

    updToDate(state, newval) {
      state.toDate2 = newval;
    },

    updsearchTerm(state, newval) {
      state.searchTerm2 = newval;
      console.log('search term2 in store is::', state.searchTerm2);
    },


    decreNum2(state, index) {
      state.num2[index]--;
    },

    addItemToCart(state, item) {
      console.log('current item is:::' + item.product_id + '::' + item.product_name);
      const current_item = state.cart.find((item1) => item1.product_id === item.product_id)
      if (current_item === undefined) {
        state.cart.push(item);
        console.log('current item not found', state.cart);
      }
      else {
        const arrayRemove = (arr, value) => {
          return arr.filter((item1) => {
            return item1.product_id != value;
          });
        }
        state.cart = arrayRemove(state.cart, item.product_id);
        state.cart.push(item);
        console.log('current item found', state.cart);
      }
      //calculate total price
      state.totalPrice = state.cart.reduce(
        (accumulator, currentValue) => accumulator + currentValue.total,
        0,
      );
      console.log('total price', state.totalPrice); // 6

      //calculate total quantity
      state.totalQuantity = state.cart.reduce(
        (accumulator, currentValue) => accumulator + currentValue.quantity,
        0,
      );
      console.log('total quantity', state.totalQuantity); // 6

    },

    clearShoppingCart(state) {
      state.cart = [];
      state.cart = [];
      state.totalPrice = 0;
      state.totalQuantity = 0;
      state.cart_id = 0;
      state.cartRetrieved = 1;
      state.message = 'Your Cart has been cleared. Please continue your shopping.';
      router.push('/searchAndAdd');
    },

    saveShoppingCart(state, cart) {
      state.cart = cart;
      console.log('cart after save cart mutation is..', state.cart);
    },

    removeItemFromCart(state, item) {
      console.log('current item is:::' + item.product_id + '::' + item.product_name);
      const current_item = state.cart.find((item1) => item1.product_id === item.product_id)
      if (current_item === undefined) {
        console.log('current item not found', state.cart);
      }
      else {
        const arrayRemove = (arr, value) => {
          return arr.filter((item1) => {
            return item1.product_id != value;
          });
        }
        state.cart = arrayRemove(state.cart, item.product_id);
        console.log('current item found', state.cart);
      }

      //calculate total price
      state.totalPrice = state.cart.reduce(
        (accumulator, currentValue) => accumulator + currentValue.total,
        0,
      );
      console.log('total price', state.totalPrice); // 6

      //calculate total quantity
      state.totalQuantity = state.cart.reduce(
        (accumulator, currentValue) => accumulator + currentValue.quantity,
        0,
      );
      console.log('total quantity', state.totalQuantity); // 6
    },

    updateNum2(state, num1) {
      state.num2 = num1;
      console.log('num2 mutation==', state.num2);
    },

    updateMessage(state, msg) {
      state.message = msg;
      console.log('message mutation==', state.message);
    },

    updateProducts(state, products) {
      state.products = products;
      console.log('products mutation==', state.products);
    },

    updateOrders(state, orders) {
      state.orders = orders;
      console.log('orders mutation==', state.orders);
    },

    updateSections(state, sections) {
      state.sections = sections;
      console.log('sections mutation==', state.sections);
    },

    updateSectionSelections(state, checkedSections) {
      state.sectionselections = checkedSections;
      console.log('sections mutation==', state.sectionselections);
    },

    updateGlobalSectionId(state, sectionid) {
      state.globalsectionid = sectionid;
      console.log('global section id mutation==', state.globalsectionid);
    },

    updateLoginDetails(state, userdetails) {
      state.userDetails = userdetails;
      console.log('userDetails mutation==', state.userDetails);
    },

    addSectionToStore(state, section) {
      console.log('state admin sections', state.adminsections);
      console.log('new section', section);

      state.adminsections.push(section)
    },

    addAdminProductToStore(state, product) {
      console.log('state admin products', state.adminproducts);
      console.log('new section', product);

      state.adminproducts.push(product)
    },

    updateAdminSections(state,adminsections) {
      state.adminsections = adminsections;
    },
    
    updateAdminSectionCRs(state,adminsectionCRs) {
      state.adminsectionCRs = adminsectionCRs;
    },
    
    updateStoreManagerRegistrations(state,storeManagerRegistrations) {
      state.StoreManagerRegistrations = storeManagerRegistrations;
    },


    
    

    updateAdminProducts(state,adminproducts) {
      state.adminproducts = adminproducts;
    },

  },


  actions: {

    setNum2({ commit, state }, num1) {
      commit('updateNum2', num1);
    },

    setMessage({ commit, state }, msg) {
      commit('updateMessage', msg);
    },

    initMessage({ commit, state }) {
      commit('updateMessage', 'Welcome to KA Mart. Your trusted online grocey store.');
    },

    setCheckedSections2({ commit, state }, newval) {
      commit('updateCheckedSections2', newval);
    },

    async saveCartAsync({ commit, state }) {
      let cart = state.cart;
      console.log('cart about to save....', cart);

      const payload = {
        cart: state.cart,
        userid: state.userDetails.user_id,
        totalPrice: (state.totalPrice*1.1).toFixed(2),
        totalQuantity: state.totalQuantity,
      };
      const path = 'http://localhost:5000/cart';
      try {
        const res = await axios.post(path, payload);
        console.log('CART===' + JSON.parse(res.data.cart));
        console.log('PRICE CART===' + JSON.parse(res.data.totalPrice));
        console.log('QUANTITY CART===' + JSON.parse(res.data.totalQuantity));
        let cart1 = JSON.parse(res.data.cart);
        let price1 = JSON.parse(res.data.totalPrice);
        let quantity1 = JSON.parse(res.data.totalQuantity);
        let cart_id1 = JSON.parse(res.data.cart_id);
        commit('saveShoppingCart', cart1);
        state.totalPrice = price1;
        state.totalQuantity = quantity1;
        state.cart_id = cart_id1;
        state.cartRetrieved = 0;
        return res;
      }
      catch (error) {
        console.error(error);
      }

    },

    saveCart({ commit, state }) {
      let cart = state.cart;
      console.log('cart about to save....', cart);

      const payload = {
        cart: state.cart,
        userid: state.userDetails.user_id,
        totalPrice: state.totalPrice,
        totalQuantity: state.totalQuantity,
      };
      const path = 'http://localhost:5000/cart';
      axios.post(path, payload)
        .then((res) => {
          console.log('CART===' + JSON.parse(res.data.cart));
          console.log('PRICE CART===' + JSON.parse(res.data.totalPrice));
          console.log('QUANTITY CART===' + JSON.parse(res.data.totalQuantity));
          let cart1 = JSON.parse(res.data.cart);
          let price1 = JSON.parse(res.data.totalPrice);
          let quantity1 = JSON.parse(res.data.totalQuantity);
          let cart_id1 = JSON.parse(res.data.cart_id);
          commit('saveShoppingCart', cart1);
          state.totalPrice = price1;
          state.totalQuantity = quantity1;
          state.cart_id = cart_id1;
          state.cartRetrieved = 0;
          state.message = 'Your Cart has been saved. Please continue your shopping.';
          router.push('/searchAndAdd');
        })
        .catch((error) => {
          console.error(error);
        });
    },

    getCart({ commit, state }) {
      console.log('cart retrieved is..', state.cartRetrieved);
      if (state.cartRetrieved == 0) {
        let userid = state.userDetails.user_id;
        const path = 'http://localhost:5000/cart';
        axios.get(path, { params: { user_id: userid } })
          .then((res) => {
            console.log('raw response==', res.data);
            try {
              console.log('CART===' + JSON.parse(res.data.cart));
              console.log('PRICE CART===' + JSON.parse(res.data.totalPrice));
              console.log('QUANTITY CART===' + JSON.parse(res.data.totalQuantity));
              console.log('CART ID===' + JSON.parse(res.data.cart_id));
              let cart1 = JSON.parse(res.data.cart);
              let price1 = JSON.parse(res.data.totalPrice);
              let quantity1 = JSON.parse(res.data.totalQuantity);
              let cart_id1 = JSON.parse(res.data.cart_id);
              commit('saveShoppingCart', cart1);
              state.totalPrice = price1;
              state.totalQuantity = quantity1;
              state.cart_id = cart_id1;
              state.cartRetrieved = 1;
            }
            catch (e) {
              console.log('There was error in getCart from server', res.data);
              console.log('restting cart to empty');
              state.cart = [];
              state.totalPrice = 0;
              state.totalQuantity = 0;
              state.cart_id = 0;
              state.cartRetrieved = 1;
            }
          })
          .catch((error) => {
            console.error(error);
            state.cart = [];
            state.totalPrice = 0;
            state.totalQuantity = 0;
            state.cart_id = 0;
            state.cartRetrieved = 1;
          });
      }
    },

    getProducts({ commit }) {
      const path = 'http://localhost:5000/products';
      axios.get(path)
        .then((res) => {
          commit('updateProducts', JSON.parse(res.data.products));
          console.log('PRODUCTS===' + JSON.parse(res.data.products));

        })
        .catch((error) => {
          console.error(error);
        });
    },

    getOrders({ commit, state }) {
      let userid = state.userDetails.user_id;
      const path = 'http://localhost:5000/orders';
      axios.get(path, { params: { user_id: userid } })
        .then((res) => {
          commit('updateOrders', JSON.parse(res.data.orders));
          console.log('ORDERS===' + JSON.parse(res.data.orders));
        })
        .catch((error) => {
          console.error(error);
        });
    },


    async placeOrder({ commit, state }) {
      //const res1 = await this.saveCart(commit,state); 
      let res1 = await this.dispatch('saveCartAsync');
      console.log('save cart response is', res1)
      const payload = {
        cartid: state.cart_id,
        userid: state.userDetails.user_id,
      };
      const path = 'http://localhost:5000/place_order';
      try {
        const res = await axios.post(path, payload)

        console.log('response from create order is', res.data);
        let orderid = JSON.parse(res.data.order_id);
        let msg = 'Your Order #' + orderid + ' has been successfully placed. Please continue your shopping.';
        if (orderid == 0) {
          msg = 'Please add a product to the Cart to place an Order.';
        }
        commit('updateMessage', msg);
        router.push('/searchAndAdd');

      }
      catch (error) {
        console.error(error);
      };
    },

    doLogin({ commit, state }, payload) {
      const path = 'http://localhost:5000/customerLogin';
      axios.post(path, payload)
        .then((res) => {
          console.log('res.data is', res.data);
          let status= res.data.status
          
          if (status == 'failure') {
            let error = res.data.error;
            commit('updateMessage', error);
            router.push('/customerLogin');
          }
          else {
            commit('updateLoginDetails', res.data);
            let msg = 'Welcome back to KA Mart. Your trusted online grocery shop.';
            commit('updateMessage', msg);
            router.push('/searchAndAdd');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    adminLogin({ commit, state }, payload) {
      const path = 'http://localhost:5000/adminLogin';
      axios.post(path, payload)
        .then((res) => {
          console.log('res.data is', res.data);
          let status= res.data.status
          
          if (status == 'failure') {
            let error = res.data.error;
            commit('updateMessage', error);
            router.push('/adminLogin');
          }
          else {
            commit('updateLoginDetails', res.data);
            let msg = 'Welcome back to KA Mart. Your trusted online grocery shop.';
            commit('updateMessage', msg);
            router.push('/adminDashboard');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    
    storeManagerLogin({ commit, state }, payload) {
      const path = 'http://localhost:5000/storeManagerLogin';
      axios.post(path, payload)
        .then((res) => {
          console.log('res.data is', res.data);
          let status= res.data.status
          
          if (status == 'failure') {
            let error = res.data.error;
            commit('updateMessage', error);
            router.push('/storeManagerLogin');
          }
          else {
            commit('updateLoginDetails', res.data);
            let msg = 'Welcome back to KA Mart. Your trusted online grocery shop.';
            commit('updateMessage', msg);
            router.push('/storeManagerDashboard');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    
    customerRegister({ commit, state }, payload) {
      const path = 'http://localhost:5000/customerRegister';
      axios.post(path, payload)
        .then((res) => {
          console.log('res.data is', res.data);
          let status= res.data.status
          
          if (status == 'failure') {
            let error = res.data.error;
            commit('updateMessage', error);
            router.push('/customerRegister');
          }
          else {
            commit('updateLoginDetails', res.data);
            let msg = 'Welcome to KA Mart. Please login to start Shopping.';
            commit('updateMessage', msg);
            router.push('/customerLogin');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    storeManagerRegister({ commit, state }, payload) {
      const path = 'http://localhost:5000/storeManagerRegister';
      axios.post(path, payload)
        .then((res) => {
          console.log('res.data is', res.data);
          let status= res.data.status
          
          if (status == 'failure') {
            let error = res.data.error;
            commit('updateMessage', error);
            router.push('/storeManagerRegister');
          }
          else {
            commit('updateLoginDetails', res.data);
            let msg = 'Your Registration is successful. You can login once you are approved by the admin.';
            commit('updateMessage', msg);
            router.push('/storeManagerLogin');
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    
    searchProducts({ commit, state }, searchTerm) {

      const path = 'http://localhost:5000/products';
      axios.post(path, searchTerm)
        .then((res) => {
          commit('updateProducts', JSON.parse(res.data.products));
          console.log('PRODUCTS===' + JSON.parse(res.data.products));

        })
        .catch((error) => {
          console.error(error);
        });
    },

    getSections({ commit }) {
      const path = 'http://localhost:5000/sections';
      axios.get(path)
        .then((res) => {
          commit('updateSections', JSON.parse(res.data.sections));
          console.log('SECTIONS===' + JSON.parse(res.data.sections));
        })
        .catch((error) => {
          console.error(error);
        });
    },
  
    updateSections({ commit, state }, sections) {
      commit('updateSections', sections);
    },


    checkout({ commit, state }) {
      router.push('/checkout');
    },


    gotoLogin({ commit, state }) {
      state.products = [];
      state.sections = [];
      state.cart = [];
      state.orders = [];
      state.sectionselections = [];
      state.count = 0,
      state.num2 = Array(100).fill(0);
      state.checkedSections2 = [];
      state.fromPrice2 = '';
      state.toPrice2 = '';
      state.fromDate2 = '',
      state.toDate2 = '';
      state.searchTerm2 = '';
      state.userDetails = '';
      state.message = '';
      state.cartRetrieved = 0,
      router.push('/customerLogin');
    },

    gotoAdminLogin({ commit, state }) {     
      state.message = '';
      state.userDetails = '';
      state.cartRetrieved = 0,
      router.push('/adminLogin');
    },

    gotoMainMenu({ commit, state }) {     
      state.message = '';
      state.cartRetrieved = 0,
      router.push('/');
    },

    gotoStoreManagerLogin({ commit, state }) {     
      state.message = '';
      state.userDetails = '';
      state.cartRetrieved = 0,
      router.push('/storeManagerLogin');
    },

    setGlobalSectionId({ commit, state }, sectionid) {
      commit('updateGlobalSectionId', sectionid);
    },

    getFilteredProducts({ commit, state }, checkedFilters) {
      commit('updateSectionSelections', checkedFilters);
    },

    updateCount({ commit, state }) {
      commit('increment');
    },
    updateFromPrice({ commit, state }, payload) {
      commit('updFromPrice', payload);
    },
    updateToPrice({ commit, state }, payload) {
      commit('updToPrice', payload);
    },

    updateFromDate({ commit, state }, payload) {
      commit('updFromDate', payload);
    },
    updateToDate({ commit, state }, payload) {
      commit('updToDate', payload);
    },

    updateSearchTerm({ commit, state }, payload) {
      commit('updsearchTerm', payload);
    },

    updateCart({ commit, state }, payload) {
      commit('addItemToCart', payload);
    },

    incNum2({ commit, state }, index) {
      commit('increNum2', index);
    },

    chgNum2({ commit, state }, index, newval) {
      commit('changeNum2', index, newval);
    },

    decNum2({ commit, state }, index) {
      commit('decreNum2', index);
    },

    removeFromCart({ commit, state }, product) {
      commit('removeItemFromCart', product);
    },

    clearCart({ commit, state }) {
      commit('clearShoppingCart');
    },

    getAdminSections({ commit }) {
      const path = 'http://localhost:5000/adminsections';
      axios.get(path)
        .then((res) => {
           commit('updateAdminSections', JSON.parse(res.data.adminsections));
           console.log('AdminSections===' + JSON.parse(res.data.adminsections));
           //console.log('jsonpaesss==', JSON.parse(res.data));

        })
        .catch((error) => {
          console.error(error);
        });
    },

    
    getAdminSectionCRs({ commit }) {
      const path = 'http://localhost:5000/adminsectionCRs';
      axios.get(path)
        .then((res) => {
          commit('updateAdminSectionCRs', JSON.parse(res.data.adminsectionCRs));
          console.log('AdminSectionCRs===' + JSON.parse(res.data.adminsectionCRs));
          //console.log('jsonpaesss==', JSON.parse(res.data));

        })
        .catch((error) => {
          console.error(error);
        });
    },

    
    getStoreManagerRegistrations({ commit }) {
      const path = 'http://localhost:5000/storeManagerRegistrations';
      axios.get(path)
        .then((res) => {
          commit('updateStoreManagerRegistrations', JSON.parse(res.data.storeMgrRegistrations));
          console.log('updateStoreManagerRegistrations===' + JSON.parse(res.data.storeMgrRegistrations));
          //console.log('jsonpaesss==', JSON.parse(res.data));

        })
        .catch((error) => {
          console.error(error);
        });
    },


    


    getAdminProducts({ commit }) {
      const path = 'http://localhost:5000/adminproducts';
      axios.get(path)
        .then((res) => {
          commit('updateAdminProducts', JSON.parse(res.data.adminproducts));
          console.log('AdminProducts===' + JSON.parse(res.data.adminproducts));
          //console.log('jsonpaesss==', JSON.parse(res.data));

        })
        .catch((error) => {
          console.error(error);
        });
    },
    
    exportProductsCSV({ commit, state }) {

      let email = state.userDetails.email;
      const path = 'http://localhost:5000/exportToCSV';
      axios.get(path, { params: { email: email } })
        .then((res) => {          
          console.log('exportToCSV ===' + res.data.status);
          let status = res.data.status;
          let msg = 'Request failed.';
          if (status == 'success') {
            msg = 'You request has been submitted. You will receive email once completed.';            
          }
          commit('updateMessage', msg);

        })
        .catch((error) => {
          console.error(error);
          let msg = 'Request failed.';        
          commit('updateMessage', msg);
        });
    },
    
    addSectionToStore({ commit, state }, section) {
     const path = 'http://localhost:5000/adminsections';
      axios.post(path, section)
        .then((res) => {
          console.log('new section', res.data.newsection);
          commit('addSectionToStore', JSON.parse(res.data.newsection)[0]);
          this.message = 'Admin section added!';
        })
        .catch((error) => {
          console.log(error);
        });
    },

    addSectionCRToStore({ commit, state }, section) {
      const path = 'http://localhost:5000/adminsectionCRs';
      axios.post(path, section)
        .then((res) => {
          console.log('new section CR', res.data.newsectionCR);
          commit('addSectionCRToStore', JSON.parse(res.data.newsectionCR)[0]);
          this.message = 'Admin section added!';
        })
        .catch((error) => {
          console.log(error);
        });
    },

    addAdminProductToStore({ commit, state }, product) {
      console.log('Add product data is', product.data);
      const path = 'http://localhost:5000/adminproducts';
      axios.post(path, product)
        .then((res) => {
          console.log('new admin product', res.data.newproduct);
          commit('addAdminProductToStore', JSON.parse(res.data.newproduct)[0]);
          this.message = 'Admin product added!';
        })
        .catch((error) => {
          console.log(error);
        });
    },

    
     
    editSectionToStore({ commit, state }, payload) {    
      console.log('section id in store is..', payload.sectionid);
      let section = payload.fd;
      let sectionid = payload.sectionid;
      const path = 'http://localhost:5000/adminsections/' + sectionid;
      console.log('edit path is', path);
      axios.put(path, section)
        .then((res) => {
          this.dispatch('getAdminSections');
        })
        .catch((error) => {
          console.log(error);
        });
    },

      
    editSectionCRToStore({ commit, state }, payload) {    
      console.log('section id in store is..', payload.sectionid);
      let section = payload.fd;
      let sectionid = payload.sectionid;
      const path = 'http://localhost:5000/adminsectionCRs/' + sectionid;
      console.log('edit path is', path);
      axios.put(path, section)
        .then((res) => {
          this.dispatch('getAdminSectionCRs');
        })
        .catch((error) => {
          console.log(error);
        });
    },

    editStoreMgrRegistrationToStore({ commit, state }, payload) {    
      console.log('user id in store is..', payload.user_id);
      let userDetail = payload.fd;
      let userid = payload.user_id;
      const path = 'http://localhost:5000/storeManagerRegistrations/' + userid;
      console.log('edit path is', path);
      axios.put(path, userDetail)
        .then((res) => {
          this.dispatch('getStoreManagerRegistrations');
        })
        .catch((error) => {
          console.log(error);
        });
    },

    editAdminProductToStore({ commit, state }, payload) {    
      console.log('section id in store is..', payload.sectionid);
      let product = payload.fd;
      let productid = payload.productid;
      const path = 'http://localhost:5000/adminproducts/' + productid;
      console.log('edit path is', path);
      axios.put(path, product)
        .then((res) => {
          this.dispatch('getAdminProducts');
        })
        .catch((error) => {
          console.log(error);
        });
    },    

    deleteSectionToStore({ commit, state }, sectionid) {
    
      console.log('section id in delete store is..', sectionid);     
      const path = 'http://localhost:5000/adminsections/' + sectionid;
      console.log('delete path is', path);
      axios.delete(path)
        .then((res) => {
          this.dispatch('getAdminSections');
        })
        .catch((error) => {
          console.log(error);
        });
    },

    deleteSectionCRToStore({ commit, state }, sectionid) {
    
      console.log('section id in delete store is..', sectionid);     
      const path = 'http://localhost:5000/adminsectionCRs/' + sectionid;
      console.log('delete path is', path);
      axios.delete(path)
        .then((res) => {
          this.dispatch('getAdminSectionCRs');
        })
        .catch((error) => {
          console.log(error);
        });
    },

    deleteProductToStore({ commit, state }, productid) {
    
      console.log('section id in delete store is..', productid);     
      const path = 'http://localhost:5000/adminproducts/' + productid;
      console.log('delete path is', path);
      axios.delete(path)
        .then((res) => {
          this.dispatch('getAdminProducts');
        })
        .catch((error) => {
          console.log(error);
        });
    },

    completeCR({commit, state}, { decision, reqid}) {
      console.log('decision1=',decision);
      console.log('reqid1=',reqid);
    },

    

  },
});