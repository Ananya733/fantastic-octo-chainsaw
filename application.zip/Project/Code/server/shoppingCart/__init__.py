import os
from flask import Flask
from flask_cors import CORS
import api  
import auth
import db
from createDB import initializeDatabase

initializeDatabase()

# create and configure the app
app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY='dev',
    DATABASE=os.path.join(app.instance_path, 'shopdbV2.sqlite3'),
)

print(app.instance_path)

db.init_app(app)

app.register_blueprint(auth.bp)
# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}})    

app.register_blueprint(api.bp)
app.add_url_rule('/', endpoint='index')

app.run(host='0.0.0.0', port='5000')