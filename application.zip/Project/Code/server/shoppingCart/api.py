from flask import(
    Flask, Blueprint, flash, g, redirect, render_template, request, url_for, session, jsonify
)
import os
import json
import datetime
from flask_cors import CORS
from db import get_db
from helper import *
from datetime import date
from celery_app import exportProductsToCSV

app = Flask(__name__,  static_folder = "static")

bp = Blueprint('api', __name__)

# enable CORS
CORS(bp, resources={r'/*': {'origins': '*'}})

@bp.route('/products', methods=('GET', 'POST'))
def products():
    response_object = {'status': 'success'}
    if request.method == 'GET':
        PRODUCTS = get_products('')
        response_object['products'] = PRODUCTS
    if request.method == 'POST':
        payload = request.get_json()
        PRODUCTS = get_products(payload.get('searchTerm'))
        response_object['products'] = PRODUCTS
    return jsonify(response_object)

@bp.route('/cart', methods=('GET', 'POST'))
def cart():
    response_object = {'status': 'success'}
    if request.method == 'GET':       
        userId = request.args.get('user_id')
        print('user id for cart get is', userId)
        CART, quantity, price, cart_id = get_cart(userId)
        response_object['cart'] = CART
        response_object['totalQuantity'] = quantity
        response_object['totalPrice'] = price
        response_object['cart_id'] = cart_id
        print('final response object from get is..', response_object)        
    if request.method == 'POST':
        payload = request.get_json()
        #print('cart payload is', payload)
        CART, quantity, price, cart_id = SavecartToDB(payload)
        response_object['cart'] = CART
        response_object['totalQuantity'] = quantity
        response_object['totalPrice'] = price
        response_object['cart_id'] = cart_id
        print('final response object from post is..', response_object)
    return jsonify(response_object)

@bp.route('/sections', methods=('GET', 'POST'))
def sections():
    response_object = {'status': 'success'}
    if request.method == 'GET':
        SECTIONS = get_sections()
        response_object['sections'] = SECTIONS
    return jsonify(response_object)

@bp.route('/orders', methods=('GET', 'POST'))
def orders():
    response_object = {'status': 'success'}
    if request.method == 'GET':
        userId = request.args.get('user_id')
        print('user id for cart get is', userId)
        ORDERS = get_orders(userId)
        response_object['orders'] = ORDERS
    return jsonify(response_object)   

@bp.route('/place_order', methods=('GET','POST'))
def place_order():
    response_object = {'status': 'success'}          
    if request.method == 'POST':
        payload = request.get_json()
        print('order payload is', payload)
        order_id = create_order(payload.get('cartid'), payload.get('userid'))
        response_object['order_id'] = order_id      
        print('final response object from post is..', response_object)
    return jsonify(response_object)

@bp.route('/adminsections', methods=['GET', 'POST'])
def all_adminsections():
    ADMINSECTIONS = []
    get_db()
    response_object = {'status': 'success'}
    if request.method == 'POST':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)
        newsection = add_adminsection(post_data, request)
        print("new section==",newsection )
        ADMINSECTIONS.append(newsection)
        response_object['message'] = 'Section added!'
        response_object['newsection'] = newsection
    else:
        ADMINSECTIONS = get_adminsections()
        response_object['adminsections'] = ADMINSECTIONS
    return jsonify(response_object)

@bp.route('/adminproducts', methods=['GET', 'POST'])
def all_adminproducts():
    ADMINPRODUCTS = []
    get_db()
    response_object = {'status': 'success'}
    if request.method == 'POST':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)
        newproduct = add_adminproduct(post_data, request)
        print("new product==",newproduct )
        ADMINPRODUCTS.append(newproduct)
        response_object['message'] = 'Section added!'
        response_object['newproduct'] = newproduct
    else:
        ADMINPRODUCTS = get_adminproducts()
        response_object['adminproducts'] = ADMINPRODUCTS
    return jsonify(response_object)


@bp.route('/adminsections/<adminsection_id>', methods=['PUT', 'DELETE'])
def single_adminsection(adminsection_id):
    response_object = {'status': 'success'}
    if request.method == 'PUT':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)       
        update_adminsection(post_data, request, adminsection_id)      
        response_object['message'] = 'Section updated!'
    if request.method == 'DELETE':
        remove_adminsection(adminsection_id)
        response_object['message'] = 'Section removed!'
    return jsonify(response_object)


@bp.route('/adminproducts/<adminproduct_id>', methods=['PUT', 'DELETE'])
def single_adminproduct(adminproduct_id):
    response_object = {'status': 'success'}
    if request.method == 'PUT':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)       
        update_adminproduct(post_data, request, adminproduct_id)      
        response_object['message'] = 'Product updated!'
    if request.method == 'DELETE':
        remove_adminproduct(adminproduct_id)
        response_object['message'] = 'Product removed!'
    return jsonify(response_object)


@bp.route('/adminsectionCRs', methods=['GET', 'POST'])
def all_adminsectionCRs():
    ADMINSECTIONCRS = []
    get_db()
    response_object = {'status': 'success'}
    if request.method == 'POST':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)
        newsectionCR = add_adminsectionCR(post_data, request)
        print("new section==",newsectionCR )
        ADMINSECTIONCRS.append(newsectionCR)
        response_object['message'] = 'Section added!'
        response_object['newsectionCR'] = newsectionCR
    else:
        ADMINSECTIONCRS = get_adminsectionCRs()
        response_object['adminsectionCRs'] = ADMINSECTIONCRS
    return jsonify(response_object)


@bp.route('/adminsectionCRs/<adminsection_id>', methods=['PUT', 'DELETE'])
def single_adminsectionCR(adminsection_id):
    response_object = {'status': 'success'}
    if request.method == 'PUT':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)       
        update_adminsectionCR(post_data, request, adminsection_id)      
        response_object['message'] = 'Section updated!'
    if request.method == 'DELETE':
        remove_adminsectionCR(adminsection_id)
        response_object['message'] = 'Section removed!'
    return jsonify(response_object)

@bp.route('/storeManagerRegistrations', methods=('GET','POST'))
def storeManagerRegistrations():
    STOREMGRREGISTRATIONS = []
    get_db()
    response_object = {'status': 'success'}
    if request.method == 'GET':      
        STOREMGRREGISTRATIONS = get_storeManagerRegistrations()
        response_object['storeMgrRegistrations'] = STOREMGRREGISTRATIONS
    return jsonify(response_object)


@bp.route('/storeManagerRegistrations/<user_id>', methods=['PUT','DELETE'])
def single_storeManagerRegistrations(user_id):
    response_object = {'status': 'success'}
    if request.method == 'PUT':
        post_data = request.form.get('data')
        print('Attention... post data is', request.form.get('data'))        
        post_data = json.loads(post_data)       
        update_storeManagerRegistrations(post_data)      
        response_object['message'] = 'Store Manager Record updated!'   
    return jsonify(response_object)

@bp.route('/exportToCSV', methods=('GET','POST'))
def exportToCSV():
    response_object = {'status': 'success'}   
    try:
        if request.method == 'GET':
            email = request.args.get('email') 
            print('email in flask is', email) 
            exportProductsToCSV(email)
    except Exception as e:
            response_object['status'] = 'failure'
    print('response object==', response_object)
    return jsonify(response_object)