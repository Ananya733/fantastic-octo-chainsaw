import functools
from flask_cors import CORS
from flask import (
    Flask, Blueprint, flash, g, redirect, render_template, request, session, url_for, jsonify
)
from werkzeug.security import check_password_hash, generate_password_hash

from db import get_db

bp = Blueprint('auth', __name__)


# instantiate the app
# app = Flask(__name__,  static_folder = "static")

# enable CORS
CORS(bp, resources={r'/*': {'origins': '*'}})


@bp.route('/customerRegister', methods=('GET', 'POST'))
def customerRegister():
    if request.method == 'POST':
        post_data = request.get_json()
        print('post_Data=', post_data)
        username = post_data.get('username')
        password = post_data.get('password')
        response_object = {'status': 'success'}       
        firstname =post_data.get('firstname')
        lastname =post_data.get('lastname')
        email =post_data.get('email')
        phone =post_data.get('phone')
        shipping_addr =post_data.get('shippingaddress')
        city =post_data.get('city')
        state =post_data.get('state')
        country =post_data.get('country')
        PIN =post_data.get('pin')
        db = get_db()
        error = None        
        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
            
        if error is None:
            try:
                db.execute(
                    "INSERT INTO User (username, password, firstname, lastname, email, phone, shipping_addr, city, state, country, PIN) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",
                    (username, generate_password_hash(password), firstname, lastname, email, phone, shipping_addr, city, state, country, PIN),
                )
                db.commit()
            except db.IntegrityError:
                error = f"User {username} is already registered."
                response_object['error'] = error
                response_object['status'] = 'failure'
        else:
            response_object['error'] = error
            response_object['status'] = 'failure'
    return jsonify(response_object)         
       


@bp.route('/storeManagerRegister', methods=('GET', 'POST'))
def storeManagerRegister():
    try:
        print('I am in admin register')
        if request.method == 'POST':
            post_data = request.get_json()
            print('post_Data=', post_data)
            username =post_data.get('username')
            password =post_data.get('password')
            email =post_data.get('email')
            response_object = {'status': 'success'}       
            db = get_db()
            error = None        
            if not username:
                error = 'Username is required.'
            elif not password:
                error = 'Password is required.'
                
            if error is None:
                try:
                    db.execute(
                        "INSERT INTO admin (username, status, approvalstatus, role, password, email) VALUES (?,?,?,?,?,?)",
                        (username, 'new', 'new', 'storemanager', generate_password_hash(password), email,)
                    )
                    db.commit()
                except db.IntegrityError as e:                  
                    error = f"User {username} is already registered."
                    response_object['error'] = error
                    response_object['status'] = 'failure'
                else:
                    error = None
            else:
                response_object['error'] = error
                response_object['status'] = 'failure'
                   
    except Exception as e:           
            print('errormessage is', e)
    return jsonify(response_object)   
    
@bp.route('/customerLogin', methods=('GET', 'POST'))
def customerLogin():
    if request.method == 'POST':
        print('I am here')
        post_data = request.get_json()
        print('post_Data=', post_data)
        username = post_data.get('username')
        password = post_data.get('password')
        response_object = {'status': 'success'}
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = \'' + username + '\''
        ).fetchone()
        
        if user is None:
            error = 'Incorrect username.'
            response_object['status'] = 'failure'
            response_object['error'] = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
            response_object['status'] = 'failure'
            response_object['error'] = 'Incorrect password.'
            
        if error is None:           
            response_object['user_id'] = user['user_id']
            response_object['admin'] = 0
            response_object['_productcode'] = None
            response_object['inError'] = 'No'
            response_object['greetingName'] = user['firstname'] + ' ' + user['lastname']
            response_object['firstname'] = user['firstname']
            response_object['lastname'] = user['lastname']
            response_object['phone'] = user['phone']
            response_object['shipping_addr'] = user['shipping_addr']
            response_object['city'] = user['city']
            response_object['state'] = user['state']
            response_object['country'] = user['country']
            response_object['PIN'] = user['PIN'] 
            response_object['email'] = user['email'] 
            response_object['role'] = 'customer' 
        return jsonify(response_object)        
        

@bp.route('/storeManagerLogin', methods=('GET', 'POST'))
def storeManagerLogin():

    if request.method == 'POST':
        post_data = request.get_json()
        print('post_Data=', post_data)
        username = post_data.get('username')
        password = post_data.get('password')
        response_object = {'status': 'success'}
        db = get_db()
        error = None
        qry = 'SELECT * FROM admin WHERE role = \'storemanager\' and status = \'active\' and username = \'' + str(username) + '\''
        print('qry==', qry)
        user = db.execute(qry).fetchone()
        
        if user is None:
            error = 'Incorrect username.'
            response_object['error'] = 'Incorrect username.'
            response_object['status'] = 'failure'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
            response_object['error'] = 'Incorrect password.'
            response_object['status'] = 'failure'
            
        if error is None:           
            response_object['user_id'] = user['admin_code']
            response_object['username'] = user['username']
            response_object['email'] = user['email']
            response_object['admin'] = 1
            response_object['role'] = 'storemanager'

        return jsonify(response_object)
    
@bp.route('/adminLogin', methods=('GET', 'POST'))
def adminLogin():

    if request.method == 'POST':
        post_data = request.get_json()
        print('post_Data=', post_data)
        username = post_data.get('username')
        password = post_data.get('password')
        response_object = {'status': 'success'}
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM admin WHERE role=\'admin\' and status=\'active\' and username = \'' + username + '\''
        ).fetchone()
        
        if user is None:
            response_object['status'] = 'failure'
            error = 'Incorrect username.'
            response_object['error'] = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
            response_object['error'] = 'Incorrect password.'
            response_object['status'] = 'failure'
            
        if error is None:           
            response_object['user_id'] = user['admin_code']
            response_object['admin'] = 1
            response_object['role'] = 'admin'
      
        return jsonify(response_object)

