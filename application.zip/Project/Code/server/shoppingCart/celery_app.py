import sqlite3
from celery import Celery
import csv
import json
from celery.schedules import crontab
from celery_tasks import add, checkUserActivity, sendEmail, monthlyActivityReport

celery = Celery(
    __name__,
    broker="redis://127.0.0.1:6379/0",
    backend="redis://127.0.0.1:6379/0"    
)


celery.conf.beat_schedule = {
    'add-every-30-seconds': {
        'task': 'celery_tasks.checkUserActivity',
        'schedule': 30.0,
        'args': ()
    },
    'another-cron-job' : {
        'task': 'celery_tasks.monthlyActivityReport',
        'schedule': 30.0,
        'args': ()
    }
}
celery.conf.timezone = 'UTC'

def query_db(query, args=(), one=False):
    conn = sqlite3.connect('/home/ananya/MAD2/server/shoppingCart/instance/shopdbV2.sqlite3')     
    cur = conn.cursor()
    cur.execute(query, args)
    r = [dict((cur.description[i][0], value) \
               for i, value in enumerate(row)) for row in cur.fetchall()]
    cur.connection.close()
    return (r[0] if r else None) if one else r


@celery.task
def add(x, y):
    z = x + y
    print(z)

@celery.task(name='divide')
def divide(x, y):
    import time
    time.sleep(5)
    return x / y

def exportProductsToCSV(email):
    export.delay(email)
    return True

@celery.task(name='export')
def export(email):
    # csv header
    
    fieldnames = ['product_id', 'product_name','price', 'measure_of_units','available_qty','units_sold', 'section_id','section_name','Manufacture_or_Expiry_Date']
    finalquery = 'select product_id, product_name,price, measure_of_units, available_qty, units_sold, p.section_id, c.section_name, strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date from Product p left join section c on p.section_id=c.section_id'
    my_query = query_db(finalquery)
    aList = json.dumps(my_query)
    rows = json.loads(aList)

    print('rows==', rows)
    print('email===',email)

    with open('productexport.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    
    # storing the subject 
    subject = "Product Export"    
    # string to store the body of the mail 
    body = "Latest status of all the products in the shop"
    #recipients = ['21f3002207@gmail.com']
    recipients = [email]
    toaddr = ", ".join(recipients)
    attachment = open("/home/ananya/MAD2/server/shoppingCart/productexport.csv", "rb") 

    sendEmail(toaddr, subject, body, '', recipients, attachment)

    return True
