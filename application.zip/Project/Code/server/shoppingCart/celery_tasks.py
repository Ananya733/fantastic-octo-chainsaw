from celery import shared_task
import sqlite3

# libraries to be imported 
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 
from datetime import datetime, date


@shared_task()
def add(x, y):
    return x + y


@shared_task()
def checkUserActivity():
    conn = sqlite3.connect('/home/ananya/MAD2/server/shoppingCart/instance/shopdbV2.sqlite3')     
    cur = conn.cursor()
    #get list of all users 
    query1 = 'select user_id, email from user'
    allusers = cur.execute(query1).fetchall()
    print('allusers==', allusers)
    alluserset = set()
    for user in allusers:
        user_id = int(user[0])
        alluserset.add(int(user[0]))
    print('alluserset=',alluserset)
    #check the orders table if the user has an order/cart
    query2 = 'select user_id  from Orders where order_date =  DATE(\'now\')'
    orders = cur.execute(query2).fetchall()    
    query3 = 'select user_id from cart where created_date =  DATE(\'now\')'
    carts = cur.execute(query3).fetchall()   
    cur.connection.close()

    activeuserset = set()
    for order in orders:
        activeuserset.add(int(order[0]))
    print('activeuserset from orders=', activeuserset)
    for cart in carts:
        activeuserset.add(int(cart[0]))
    print('activeuserset from orders + cart', activeuserset)

    #remove activeusers from allusers
    for val in activeuserset:
        alluserset.remove(val)

    print('inactive users=', alluserset)
    recipients = []
    for val in alluserset:
        res = [i for i in range(len(allusers)) if allusers[i][0] == val]
        #print(type(res), allusers[int(res[0])][1])
        inactiveuser = allusers[int(res[0])][1]
        recipients.append(inactiveuser)
    print('inactiveusers = ', recipients)   
    #send email to order/add to cart
     # storing the subject 
    subject = "We are missing you at KA Mart."    
    # string to store the body of the mail 
    body = "We have exiting offers for you at KA Mart. Please visit us @KAMart.com"  
    toaddr = ", ".join(recipients)
    print('toaddr==##',toaddr)
    if (toaddr != ''):
        sendEmail(toaddr,subject,body,'', recipients, '')


def sendEmail(toaddr, subject, body, HTMLBody, recipients, attachment):
    # Python code to illustrate Sending mail with attachments 
    # from your Gmail account 

    fromaddr = "a94001879@gmail.com"

    # instance of MIMEMultipart 
    msg = MIMEMultipart() 

    # storing the senders email address 
    msg['From'] = fromaddr 

    # storing the receivers email address 
    msg['To'] = toaddr 

    # storing the subject 
    msg['Subject'] = subject

    # string to store the body of the mail 
    # body = "Latest status of all the products in the shop"

    # attach the body with the msg instance
    if (body != ''):
        msg.attach(MIMEText(body, 'plain')) 

    # attach HTM Body if given
    if (HTMLBody != ''):
        part2 = MIMEText(HTMLBody, "html")
        msg.attach(part2)

    # open the file to be sent 
    filename = "productexport.csv"
   
    # if there is an attachment to be sent
    if (attachment != ''):
        # instance of MIMEBase and named as p 
        p = MIMEBase('application', 'octet-stream')

        # To change the payload into encoded form 
        p.set_payload((attachment).read()) 

        # encode into base64 
        encoders.encode_base64(p) 

        p.add_header('Content-Disposition', "attachment; filename= %s" % filename) 

        # attach the instance 'p' to instance 'msg' 
        msg.attach(p) 


    # creates SMTP session 
    s = smtplib.SMTP('smtp.gmail.com', 587) 

    # start TLS for security 
    s.starttls() 

    # Authentication 
    s.login(fromaddr, "wfkc bvpv rrje qhrf") 

    # Converts the Multipart msg into a string 
    text = msg.as_string() 

    # sending the mail 
    s.sendmail(fromaddr, recipients, text) 

    # terminating the session 
    s.quit()     

@shared_task()
def monthlyActivityReport():
    html = """\
        <html>
        <body>
            <h1>Monthly Activity Report</h1>
                <table border=1>
                    <tr>
                        <th>Order Id</th>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Total Quantity</th>
                        <th>Order Status</th>
                        <th>Total Amount</th> 
                        <th>Order Date</th> 
                    </tr>
                    {0}
                </table>
        </body>
        </html>
        """
    #print(html)

    today = datetime.today()
    curm = date(today.year, today.month, 1)
    print('first of this month', curm)
    prevm = date(today.year, today.month-1, 1)
    print('first of last month', prevm)
    conn = sqlite3.connect('/home/ananya/MAD2/server/shoppingCart/instance/shopdbV2.sqlite3')     
    cur = conn.cursor()
    #get list of all orders in the month 
    finalquery = 'select order_id, u.username, u.email, total_quantity, order_status, total_price, strftime(\'%d-%m-%Y\', order_date) as order_date from orders p, user u where  p.user_id = u.user_id and strftime(\'%Y-%m-%d\', order_date) >= \'' + str(prevm) + '\'' \
                 ' and strftime(\'%Y-%m-%d\', order_date) < \'' + str(curm) + '\' order by order_date desc' 
    #uncomment for demo
    #finalquery = 'select order_id, u.username, u.email, total_quantity, order_status, total_price, strftime(\'%d-%m-%Y\', order_date) as order_date from orders p, user u where  p.user_id = u.user_id '
    print('finalquery is',finalquery)
    orders = cur.execute(finalquery).fetchall()   
    cur.connection.close()   
    #for order in orders:
        #print('order is..', order)    
    tr = "<tr>{0}</tr>"
    td = "<td>{0}</td>"
    subitems = [tr.format(''.join([td.format(a) for a in order])) for order in orders]
    #print(html.format("".join(subitems))) # or write, whichever
    toaddr = 'a94001879@gmail.com'
    subject = 'Monthly Activity Report'
    recipients = ['a94001879@gmail.com'] #hard coded email address of the site admin
    #send html email to admin user
    sendEmail(toaddr, subject, '', html.format("".join(subitems)), recipients, '')

    
