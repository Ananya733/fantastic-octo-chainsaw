import sqlite3
from werkzeug.security import generate_password_hash

def initializeDatabase():
        
    conn = sqlite3.connect('/home/ananya/MAD2/server/shoppingCart/instance/shopdbV2.sqlite3') 
    cur = conn.cursor()

    cur.execute('pragma encoding=UTF16')    

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Admin (
        admin_code	INTEGER,
        password	BLOB,
        role	TEXT,
        status	TEXT,
        username	TEXT UNIQUE,
        approvalstatus	TEXT,
        email	TEXT,
        PRIMARY KEY(admin_code AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Cart (
        cart_id	INTEGER,
        user_id	INTEGER,
        total_price	NUMERIC,
        total_quantity	INTEGER,
        created_date	NUMERIC,
        order_id	INTEGER,
        order_placed	TEXT DEFAULT 'No',
        PRIMARY KEY(cart_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Cart_Item (
        cart_item_id	INTEGER,
        cart_id	INTEGER,
        product_id	INTEGER,
        product_quantity	INTEGER,
        total_price	INTEGER,
        order_item_id	INTEGER,
        PRIMARY KEY(cart_item_id AUTOINCREMENT),
        FOREIGN KEY(order_item_id) REFERENCES Order_Item(order_item_id),
        FOREIGN KEY(cart_id) REFERENCES Cart(cart_id),
        FOREIGN KEY(product_id) REFERENCES Product(product_id)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Order_Item (
        order_item_id	INTEGER,
        order_id	INTEGER,
        product_id	INTEGER,
        product_quantity	INTEGER,
        total_price	NUMERIC,
        cart_item_id	INTEGER,
        PRIMARY KEY(order_item_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Orders (
        order_id	INTEGER,
        total_price	NUMERIC,
        total_quantity	TEXT,
        user_id	INTEGER,
        order_date	TEXT,
        cart_id	INTEGER,
        order_status	TEXT DEFAULT 'Unpaid',
        PRIMARY KEY(order_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Product (
        product_id	INTEGER,
        product_name	TEXT,
        price	REAL,
        available_qty	INTEGER DEFAULT 0,
        images	BLOB,
        section_id	INTEGER NOT NULL,
        measure_of_units	TEXT,
        image_name	TEXT,
        Manufacture_or_Expiry_Date	TEXT,
        units_sold	INTEGER DEFAULT 0,
        PRIMARY KEY(product_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Section (
        section_id	INTEGER,
        section_name	TEXT,
        image	BLOB,
        image_name	TEXT,
        section_description	TEXT,
        PRIMARY KEY(section_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS Section_CR (
        user_id	INTEGER,
        section_id	INTEGER,
        section_name	TEXT,
        section_description	TEXT,
        action	TEXT,
        request_id	INTEGER,
        status	TEXT,
        PRIMARY KEY(request_id AUTOINCREMENT)
        )
    ''')

    cur.execute('''            
        CREATE TABLE IF NOT EXISTS User (
        username	TEXT UNIQUE,
        user_id	INTEGER,
        password	TEXT,
        shipping_addr	TEXT,
        city	TEXT,
        state	TEXT,
        country	TEXT,
        PIN	INTEGER,
        firstname	TEXT,
        lastname	TEXT,
        email	TEXT,
        phone	TEXT,
        PRIMARY KEY(user_id AUTOINCREMENT)
        )
    ''')
    try:
        conn.execute(
                    "INSERT INTO admin (username, status, approvalstatus, role, password, email) VALUES (?,?,?,?,?,?)",
                    ('KAMartAdmin', 'active', 'approved', 'admin', generate_password_hash('Ananya2004'), 'a94001879@gmail.com',)
        )                    
        conn.commit()
    except conn.IntegrityError as e:
         print('errormessage is',  e)

    cur.connection.close()



