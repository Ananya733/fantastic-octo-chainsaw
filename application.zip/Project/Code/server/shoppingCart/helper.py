from flask import(
    Flask, Blueprint, flash, g, redirect, render_template, request, url_for, session, jsonify
)
import sqlite3
import json
import datetime
import uuid
import os
import csv

from db import get_db
from datetime import date

app = Flask(__name__,  static_folder = "static")


def query_db(query, args=(), one=False):
    #conn = sqlite3.connect('test_database.db') 
    db = get_db()
    cur = db.cursor()
    cur.execute(query, args)
    r = [dict((cur.description[i][0], value) \
               for i, value in enumerate(row)) for row in cur.fetchall()]
    cur.connection.close()
    return (r[0] if r else None) if one else r

def SavecartToDB(cart):
    # creating a list of items
    #print('jsondump of cart==', cart) 
    db = get_db()
    dd = date.today()
    cur = db.cursor()  
  
    aList = json.dumps(cart)
    aList2 = json.loads(aList)
    print('aList2 isss...', aList2)

    print('type of aList2', type(aList2) )
    print('userid is', aList2.get('userid'))
    user_id = aList2.get('userid')
    
    totalQuantity = aList2.get('totalQuantity') if aList2.get('totalQuantity') != None else 0
    print('alerting total quantity', totalQuantity)
    #totalPrice = aList2.get('totalPrice')     
    totalPrice = aList2.get('totalPrice') if aList2.get('totalPrice') != None else 0
    print('alerting total price', totalPrice)
    #first delete old cart items and cart

    existCart = db.execute(
                'select cart_id from Cart where  user_id = ' + str(user_id) 
                ).fetchone()
    if existCart is not None:
        cart_id = existCart['cart_id']
        # delete cart item
        db.execute(
            'delete from cart_item'
            ' WHERE cart_id = ?',
            (cart_id,)
        )
        print('old cart item deleted..........')
        # delete cart
        db.execute(
            'delete from cart'
            ' WHERE cart_id = ?',
            (cart_id,)
        )
        print('old cart deleted..........')
    db.execute(
                'INSERT INTO Cart (user_id, total_quantity, total_price, order_placed, created_date)'
                    ' VALUES (?,?,?,?,?)',
                    (user_id,totalQuantity,totalPrice,'No', str(dd),) 
            )
    db.commit()
    existCart = db.execute(
                'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and user_id = ' + str(user_id) 
                ).fetchone()

    cart_id =existCart['cart_id']
    print('cart_id from database is...', cart_id)
      
    my_dict = {}
    for index, element in enumerate(aList2.get('cart')):
        my_dict[index] = element
        print('element =',element)

    print(type(my_dict))
    
    sqlrows = []
    for item in my_dict.values():
       row =   str(cart_id) +str(',') + str(item.get('product_id')) + str(',') + str(item.get('total')) + str(',') + str(item.get('quantity')) 
       print('row is***', row)
       my_result = tuple(map(float, row.split(',')))
       print('my result is***', my_result)
       sqlrows.append(my_result)       
   
    print('sqlrows=', sqlrows)  
   
    c =db.cursor() 
    c.executemany(
        'INSERT INTO cart_item (cart_id,product_id,total_price, product_quantity)'
        ' VALUES (?,?,?,?)',
        sqlrows)
    db.commit()
    print('multiple rows inserted..')
    #this.addProductToCart(id,rate,qty,amount, name, imgname, section, mfgorexpdate,measure);
    usercart = db.execute(
        'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and cart_id = ' + str(cart_id) 
    ).fetchone()        
    
    cart_dict = {}
   
    if not usercart is None:
      
        qry = 'select cart_id,total_price as total,ci.product_id, p.measure_of_units as measureofunit, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as product_mfgorexpdate, section_name as product_sectionname, product_quantity as quantity, product_name, price, p.image_name as product_imagename from Cart_item ci, product p, section s where s.section_id=p.section_id and p.product_id = ci.product_id and cart_id = ' + str(cart_id)
        
        print(qry)
        my_query = query_db(qry)
        print('my_query is..', my_query)
        json_output = json.dumps(my_query)
        #print('jsondump of cart==', json_output) 
        #cart_dict['cart']=json_output
        #cart_dict['cart.totalQuantity'] = int(usercart['total_quantity'])
        #cart_dict['cart.totalPrice'] = float(usercart['total_price'])
        #cart_json = json.dumps(cart_dict)
        
        #print('cart json dump', cart_json)
    cur.connection.close()
    return json_output, int(usercart['total_quantity']), float(usercart['total_price']), int(cart_id)

def get_cart(userId):
    db = get_db()
    cur = db.cursor()
    usercart = db.execute(
        'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and user_id = ' + str(userId) 
    ).fetchone()   
    if not usercart is None:
        cart_id = usercart['cart_id']
        qry = 'select cart_id,total_price as total,ci.product_id, p.measure_of_units as measureofunit, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as product_mfgorexpdate, section_name as product_sectionname, product_quantity as quantity, product_name, price, p.image_name as product_imagename from Cart_item ci, product p, section s where s.section_id=p.section_id and p.product_id = ci.product_id and cart_id = ' + str(cart_id)
        print(qry)
        my_query = query_db(qry)
        print('my_query is..', my_query)
        json_output = json.dumps(my_query)
        #print('jsondump of cart==', json_output)
        cur.connection.close()
        return json_output, int(usercart['total_quantity']), float(usercart['total_price']), cart_id
    else:
        cur.connection.close()
        return {}, 0, 0, 0
  
def get_products(searchTerm):    
    qry = 'select product_id, product_name,price, p.section_id, p.measure_of_units, p.available_qty, 0 as qty, s.section_name, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date,  p.image_name from Product p, section s where p.section_id=s.section_id'    
    if searchTerm != '':
        qry += ' and p.product_name like \'%' + searchTerm + '%\''
    print(qry)
    my_query = query_db(qry)
    print('my_query is..', my_query)
    json_output = json.dumps(my_query)
    #print('jsondump of products==', json_output) 
    return json_output

def get_orders(userid):
    finalquery = 'select order_id, total_quantity, order_status, total_price, strftime(\'%d-%m-%Y\', order_date) as order_date from orders p where user_id = ' + str(userid) + ' order by order_id desc '
    print(finalquery)
    my_query = query_db(finalquery)
    print('my_query is..', my_query)
    json_output = json.dumps(my_query)
    #print('jsondump of orders==', json_output) 
    return json_output

def get_sections():   
    qry = 'SELECT  section_id, section_name FROM section'
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    #print('jsondump of sections==', json_output) 
    return json_output 

def create_order(code, userid):
    print('cart id for order creation =' + str(code))
    if int(code) != -1: 
        productArray = {} 
        dd = date.today()
        db = get_db()
        print('order date='+str(dd))
        cart = db.execute(
            'select total_price,total_quantity from cart where cart_id = ?', (code,)
        ).fetchall()
        retval = 0
        if cart[0]['total_quantity'] > 0:
            cartitems = db.execute(
                'select cart_item_id,cart_id,product_id,product_quantity,total_price from cart_item where cart_id = ?', (code,)
            ).fetchall()
            
            if cartitems is not None:
                #first generate order from cart
                print('cart totals='+ str(cart[0]['total_price']) +  str(cart[0]['total_quantity']) + str(userid))
                db.execute('insert into orders (total_price,total_quantity,user_id, cart_id, order_date) values (?,?,?,?,?) ', (float(cart[0]['total_price']), int(cart[0]['total_quantity']), int(userid), int(code), str(dd),))     
                db.commit()
                ord = db.execute(
                    'select order_id from orders where cart_id = ?', (code,)
                ).fetchone() 
                #second generate order items from cart items
                for cartitem in cartitems:
                    db.execute(
                        'insert into order_item (order_id,product_id, product_quantity, total_price, cart_item_id) values(?,?,?,?,?)', 
                        (ord['order_id'], cartitem['product_id'],cartitem['product_quantity'],cartitem['total_price'],cartitem['cart_item_id'],)
                    )
                    productArray[cartitem['product_id']]=cartitem['product_quantity']
                db.commit()
                #reduce inventory quanties on the product table
                products = db.execute(
                    'select product_id,available_qty, units_sold from product where product_id  in (select product_id from cart_item where cart_id = ?)',(code,)).fetchall()
            
                for product in products:
                    db.execute(
                        'UPDATE product SET available_qty = ?, units_sold = ? '
                        ' WHERE product_id = ?',
                        (int(product['available_qty']) - productArray[product['product_id']], int(product['units_sold']) + productArray[product['product_id']], product['product_id'])
                    )
                    db.commit()
                #update Cart to Order place=yes
                db.execute(
                        'UPDATE cart SET order_placed = \'Yes\''
                        ' WHERE cart_id = ?',
                        (code,)
                )
                db.commit() 
                retval = ord['order_id']           
    return retval

def get_adminsections():
    qry = 'select section_id, section_name,section_description, image_name from section'
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    return json_output  

def get_adminproducts():
    finalquery = 'select product_id, product_name,price, measure_of_units, available_qty, units_sold, p.section_id, c.section_name, strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, p.image_name from Product p left join section c on p.section_id=c.section_id'
    my_query = query_db(finalquery)
    json_output = json.dumps(my_query)
    #print('jsondump==', json_output)   
    return json_output    

def convertToBinaryData(filename):
  # Convert binary format to images or files data  
  with open( filename, 'rb') as file:
      blobData = file.read()
  return blobData

#write binary data to image file
def write_to_file(binary_data, file_name):   
    file_name = os.path.join('/home/ananya/MAD2/client/src', 'assets', file_name)
    print('file name in write to file=' + file_name)
    with open(file_name, 'wb') as file:
        file.write(binary_data)

def add_adminsection(section, request):

    fileuploaded = 0
    if request.method == 'POST':
        title = section.get('title')
        body = section.get('body')
        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
               fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                    'INSERT INTO section (section_name,section_description,image,image_name )'
                  ' VALUES (?,?,?,?)',
                (title, body, imagef,f.filename)
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                    'INSERT INTO section (section_name,section_description)'
                  ' VALUES (?,?)',
                (title, body)
                )
                db.commit()         
             
        except Exception as e:
            fileuploaded=0
            print(e)       

        error = None   
    qry = 'select section_id, section_name,section_description, image_name from section where section_name like \'' + title + '\''
    
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    #print('jsondump==', json_output)    
    return json_output

    #file.write(binary_data)

def add_adminproduct(product, request):

    fileuploaded = 0
    if request.method == 'POST':
        productname = product.get('productname')
        price = product.get('price')
        availableqty = product.get('availableqty')
        unitssold = product.get('unitssold')
        unitofmeasure = product.get('unitofmeasure')
        sectionid = product.get('sectionid') 

        if product.get('mfgDate') != '':
            date1 = datetime.datetime.strptime(product.get('mfgDate'), "%Y-%m-%d")
            date2 = str(date1.strftime('%Y-%m-%d')) 
            print('date2=' + date2)
        
        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
               fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                   'INSERT INTO Product (product_name,price, Manufacture_or_Expiry_Date, measure_of_units, available_qty, units_sold, section_id,images, image_name)'
                  ' VALUES (?,?,?,?,?,?,?,?,?)',
                (productname, price, date2, unitofmeasure, availableqty, unitssold, sectionid, imagef,f.filename)
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                    'INSERT INTO Product (product_name,price,Manufacture_or_Expiry_Date, measure_of_units, available_qty, units_sold, section_id )'
                  ' VALUES (?,?,?,?,?,?,?)',
                (productname, price, date2, unitofmeasure, availableqty, unitssold, sectionid)
                )
                db.commit()      
             
        except Exception as e:
            fileuploaded=0
            print(e)       

        error = None    
    qry = 'select product_id, product_name,price, measure_of_units, available_qty, units_sold,  p.section_id, c.section_name, strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, p.image_name from Product p left join section c on p.section_id=c.section_id and  product_name like \'' + productname + '\''
    #print('###return gift is ', qry)
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    #print('jsondump==', json_output)    
    return json_output


def remove_adminsection(section_id):
    db = get_db()
    cur = db.cursor()
    cur.execute(
                'delete from section '
                ' WHERE section_id = ?',
                (section_id,)
            )
    db.commit()
    cur.close()
    return True

def remove_adminproduct(product_id):
    db = get_db()
    cur = db.cursor()
    cur.execute(
                'delete from product '
                ' WHERE product_id = ?',
                (product_id,)
            )
    db.commit()
    cur.close()
    return True


def update_adminsection(section, request, sectionid):
    #print(request.files)
    fileuploaded = 0
    imagef=''
    f=''
    filename1=''
    if request.method == 'PUT':
        sectionname = section.get('title')
        desciption = section.get('body')       

        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
                fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                    'UPDATE Section SET section_name =?, section_description = ?, image = ?, image_name = ? '
                        ' WHERE  section_id = ? ',
                        (sectionname, desciption,  imagef, f.filename,  sectionid)    
                )
                db.commit()
                write_to_file(imagef,f.filename)
                print('Image and filename should be changed for', sectionid)
             else:
                db.execute(
                     'UPDATE Section SET section_name = ?, section_description = ? '
                        ' WHERE  section_id = ? ',
                        (sectionname, desciption,   sectionid) 
                )
                db.commit()
             
        except Exception as e:
            fileuploaded=0
            print(e)
    return True


def update_adminproduct(product, request, productid):
    #print(request.files)
    fileuploaded = 0
    imagef=''
    f=''
    filename1=''
    if request.method == 'PUT':       
        productname = product.get('productname')
        price = product.get('price')
        availableqty = product.get('availableqty')
        unitssold = product.get('unitssold')
        unitofmeasure = product.get('unitofmeasure')
        sectionid = product.get('sectionid') 
        date1 = ''
        date2 = ''
        if product.get('mfgDate') != '' and product.get('mfgDate') != None:
            date1 = datetime.datetime.strptime(product.get('mfgDate'), "%Y-%m-%d")
            date2 = str(date1.strftime('%Y-%m-%d')) 
            print('date2=' + date2)       

        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
                fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
            if fileuploaded==1:
                print('just before update..with file', productid)
                db.execute(
                    'UPDATE product SET price = ?, available_qty = ?, units_sold = ?, section_id = ?, product_name = ?, images = ?, image_name = ?, Manufacture_or_Expiry_Date = ?, measure_of_units = ?'
                        ' WHERE product_id = ?',
                        (price, availableqty, unitssold, sectionid, productname, imagef, f.filename, date2,unitofmeasure, productid)    
                )
                db.commit()
                print('right after commit..with file', productid)

                write_to_file(imagef,f.filename)
            else:
                print('reporting before product is updated..')
                db.execute(
                    'UPDATE product SET price = ?, available_qty = ?, units_sold = ?, section_id = ?, product_name = ?, Manufacture_or_Expiry_Date = ?, measure_of_units = ?'
                        ' WHERE product_id = ?',
                        (price, availableqty, unitssold, sectionid, productname, date2,unitofmeasure, productid)    
                )
                db.commit()
                print('reporting after product is updated..')
             
        except Exception as e:
            fileuploaded=0
            print('printing from exception block',e)
    return True

def update_adminsectionCR(section, request, sectionid):  
    if request.method == 'PUT':
        sectionname = section.get('title')
        description = section.get('body')
        reqid = section.get('reqid')
        decision = section.get('decision')
        action = section.get('action')

        db = get_db()
        if reqid != '' and decision != '':
            #update/delete the section
            #update the sectionCR
            print('About to take action based on', reqid, decision, sectionid)
            db.execute(
                    'UPDATE section_CR SET status = ? '
                        ' WHERE request_id = ?',
                        (decision, reqid)    
                )
            
            if (action == 'update' and decision == 'Approved'):
                # update the actual section record now
                db.execute(
                        'UPDATE section SET section_name = ?, section_description = ? '
                            ' WHERE section_id = ?',
                            (sectionname, description, sectionid,)    
                )

            if (action == 'add' and decision == 'Approved'):
            # insert the actual section record now
                db.execute(
                    'INSERT INTO section (section_name,section_description )'
                    ' VALUES (?,?)',
                    (sectionname, description,))
                
            if (action == 'delete' and decision == 'Approved'):
            # delete the actual section record now
                db.execute(
                    'delete from section '
                    ' WHERE section_id = ?',
                    (sectionid,)
                )
                
            db.commit()

        else:
            try:
                db.execute(
                    'INSERT INTO section_CR (section_id, section_name,section_description,action,status )'
                    ' VALUES (?,?,?,?,?)',
                    (sectionid, sectionname, description, "update","new")
                )
                db.commit()
                
            except Exception as e:           
                print(e)
    return True


def add_adminsectionCR(section, request):
    if request.method == 'POST':
        title = section.get('title')
        body = section.get('body')
       
        db = get_db()
        try: 
            db.execute(
                'INSERT INTO section_CR (section_name,section_description,action,status)'
                ' VALUES (?,?,?,?)',
            (title, body,"add","new")
            )
            db.commit() 
        except Exception as e:
            print(e) 
     
    qry = 'select section_id, section_name,section_description, action, status from section_CR where section_name like \'' + title + '\''
    
    #print('###return gift is ', qry)
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    print('jsondump==', json_output)    
    return json_output

def remove_adminsectionCR(section_id):
    db = get_db()
    cur = db.cursor()

    qry = 'select section_id, section_name,section_description from section where section_id = ' + str(section_id)
    section = db.execute(qry).fetchone()
    if section is not None:       
        sectionname = section['section_name']
        desciption = section['section_description']  

    db.execute(
            'INSERT INTO section_CR (section_id, section_name,section_description, action,status)'
            ' VALUES (?,?,?,?,?)',
        (section_id, sectionname, desciption, "delete","new")
        )
    db.commit()
    cur.close()
    return True

def get_adminsectionCRs():
    # connect to the database
    #conn = sqlite3.connect('test_database.db')
    #cur = conn.cursor()    
    qry = 'select request_id, section_id, section_name,section_description, action, status from section_CR order by request_id desc '
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    #print('jsondump==', json_output)   
    return json_output
    
def get_storeManagerRegistrations():
    qry = 'select admin_code as user_id, username, role, status, approvalstatus from admin where role= \'storemanager\' order by admin_code desc'
    my_query = query_db(qry)
    json_output = json.dumps(my_query)
    #print('jsondump==', json_output)   
    return json_output
    

def update_storeManagerRegistrations(registration):  
    if request.method == 'PUT':
        userid = registration.get('user_id')
        decision = registration.get('decision')     
        db = get_db()
        status = 'new'
        if userid != '' and decision != '':
            if decision == 'Approved':
                status='active'
            else:
                status='inactive'
            #update/delete the section
            #update the sectionCR
            print('About to take action based on', userid, decision)
            db.execute(
                    'UPDATE admin SET status = ?, approvalstatus = ? '
                        ' WHERE admin_code = ?',
                        (status, decision, userid)    
                )
            db.commit()       
    return True
